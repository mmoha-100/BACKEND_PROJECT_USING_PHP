if ( window.history.replaceState ) {
    window.history.replaceState(null, null, window.location.href);
}
const showNavbarBtn = document.getElementById("showNavbarBtn");
const navbarContainer = document.getElementById("navbarContainer");

if (showNavbarBtn !== null) {
    showNavbarBtn.onclick = () => {
        if (navbarContainer.classList.contains('hidden-navbar')) {
            navbarContainer.classList.remove('hidden-navbar');
        } else {
            navbarContainer.classList.add('hidden-navbar');
        }
    }
}

document.body.addEventListener("click", (e) => {
    if (e.target != showNavbarBtn && !navbarContainer.classList.contains('hidden-navbar')) {
        navbarContainer.classList.add('hidden-navbar');
    }
})

const backBtns = document.querySelectorAll("button.back-btn");
backBtns.forEach((btn) => {
    btn.onclick = () => { 
        history.back();
    }
})

function adjustHeight(el){
    el.style.height = (el.scrollHeight > el.clientHeight) ? (el.scrollHeight)+"px" : "35px";
}

const warningBtn = document.querySelectorAll(".warningBtn");
if (warningBtn !== null) {
    warningBtn.forEach(btn => {
        btn.addEventListener('click', (e) => {
            // if input:submit it will not submit
            e.preventDefault();
            if (confirm(btn.dataset.warning)) {
                location.href = btn.dataset.url;
                console.log(btn.dataset.url);
            }
        });
    })
}