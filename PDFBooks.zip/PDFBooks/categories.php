<?php
    session_start();
    ob_start();
    $_SESSION['lastPage'] = basename($_SERVER['REQUEST_URI']);
    $pageTitle = 'Categories';
    $navbar = '';
    include 'init.inc';
    $catid = isset($_GET['catid']) ? $_GET['catid']:0;
    $stmt = $db->prepare("SELECT 
                            Name,
                            Description,
                            ID 
                        FROM 
                            categories 
                        WHERE 
                            Visibility");
    $stmt->execute();
    $cats = $stmt->fetchAll();
?>
<div class="container">
            <div class='search-bar-container position-absolute <?php if(isset($_COOKIE['lang'])&&$_COOKIE['lang']=='ar') echo 'left-70'; else echo 'right-70' ?>'>        
            <form action='categories.php?search' method='POST' class='mb-0'>
                <input 
                    type='text' 
                    name='looking_for' 
                    value='<?php if(isset($_POST['looking_for'])) echo $_POST['looking_for'] ?>'
                    autocomplete="off"
                    placeholder='<?php echo lang("ENTER_KEY_WORD") ?>'
                />
                <input type='submit' value='<?php echo lang("SEARCH_BAR_BTN") ?>' />
            </form>
        </div>
    <h1 class="section"><?php echo lang("CATEGORIES_SECTION") ?></h1>
    <?php if(isset($_GET['search']) && $_SERVER['REQUEST_METHOD']=='POST'){
        $stmt = $db->prepare("SELECT * FROM books WHERE Tags LIKE ? AND Approved");
        $stmt->execute(['%'.$_POST['looking_for'].'%']);
        $booksWithTags = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if($stmt->rowCount()){
            echo 'The Results For \''.$_POST['looking_for'].'\' Key Word';
            foreach($booksWithTags as $book){
                displayBook($book);
            }                
        } else {
            echo 'No Results For <span class="text-danger">\''.$_POST['looking_for'].'\'</span> Key Word';
        }
    } else{
        if(isUsed('ID', 'categories', $catid)){ ?>
    <h2 class='catname-header mb-5'>
        <?php 
            $stmt = $db->prepare("SELECT Name FROM categories WHERE ID = ?");
            $stmt->execute([$catid]);
            echo '['.$stmt->fetcHColumn().']';
            ?>
    </h2>
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
        <?php foreach(getBooksFromCat($catid) as $book) { ?>
            <div class="col">
                <!-- Ensuring all cards have the same height -->
                <div class="card d-flex flex-column h-100 justify-self-center sm-w-100" style='width: 18rem;'>
                    <a href="show_book.php?bookid=<?php echo $book['BookID'] ?>&catid=<?php echo $book['CatID'] ?>">
                        <img loading='lazy' src="<?php echo $frontCoversContainerFolder.$book['IMG_FrontCover'] ?>" class="card-img-top" alt="...">
                        <div class="card-body d-flex flex-column rtl-dir-rtl">
                            <h4 class="card-text"><?php echo $book['Name'] ?></h4>
                            <p><?php echo truncate($book['Description'], 40) ?></p>
                            <p class="card-text mt-auto"><small class="text-body-secondary"><?php echo $book['Date'] ?></small></p>
                        </div>
                    </a>
                </div>
            </div>
        <?php } ?>
    </div>
    <?php
    } else { ?>
        <ul class='d-flex gap-4 flex-dir-column'>
            <?php 
                foreach($cats as $cat){ ?>
                    <li class='rtl-align-right'>
                        <a class='fs-2' href="categories.php?catid=<?php echo $cat['ID'] ?>">
                            <?php echo $cat['Name'] ?>
                        </a>
                        <div class='fs-5'>
                            <?php echo $cat['Description'] ?>
                        </div>
                    </li>
                <?php } ?>
        </ul>
    <?php } 
    }?>
</div>
<?php
    include $tpls.'footer.inc';
    ob_end_flush();
?>
