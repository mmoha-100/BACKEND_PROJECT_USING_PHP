<?php
    session_start();
    ob_start();

    $navbar     =  '';
    $pageTitle  =  'Settings';

    include 'init.inc';

    $_SESSION['lastPage'] = basename($_SERVER['REQUEST_URI']);
    
    if(isset($_SESSION['UserID'])){
        $stmt = $db->prepare("SELECT * FROM users WHERE UserID = ?");
        $stmt->execute([$_SESSION['UserID']]);

        $currentUser = $stmt->fetch(PDO::FETCH_ASSOC);

        if(isset($_GET['delete_account']) && $_GET['delete_account']=='(^_^;)') {
            $stmt = $db->prepare('DELETE FROM users WHERE UserID = ?');
            $stmt->execute([$_SESSION['UserID']]);
            session_destroy();
            header("Location: index.php");
        }

        if($_SERVER['REQUEST_METHOD']=='POST') {
            $arrErrors = [];

            if(isset($_POST['lang']) && array_key_exists($_POST['lang'], $langs)) {
                $lang = $_POST['lang'];
                setcookie('lang', $_POST['lang'], time()+daysToSeconds(365));
            }

            if(isset($_POST['theme']) && in_array($_POST['theme'],['light','dark'])){
                $theme = $_POST['theme'];
                setcookie('theme', $theme, time()+daysToSeconds(365));
            }

            if(isset($_POST['username']) && $_POST['username']!=''){
                $username = $_POST['username'];
            } else {
                $username = $currentUser['Username'];
            }

            if(isset($_POST['email']) && $_POST['email']!=''){
                $email = $_POST['email'];
            } else {
                $email = $currentUser['Email'];
            }

            if(isset($_POST['password']) && $_POST['password'] != ''){
                $password = $_POST['password'];
            } else {
                $password = $currentUser['Password'];
            }

            if(isset($_POST['fullName']) && $_POST['fullName'] != ''){
                $fullName = $_POST['fullName'];
            } else {
                $fullName = $currentUser['FullName'];
            }

            if(isUsed('Username', 'users', $username) && $username != $currentUser['Username']){
                $arrErrors[] = lang('USERNAME_USED_BEFORE');
            } else {
                if(strlen($username) > 100 || strlen($username) < 5){
                    $arrErrors[] = lang("USERNAME_MUST_BE_BETWEEN");
                }
                if(containsBadWord($username)){
                    $arrErrors[] = lang("USERNAME_CONTAINS_BAD_WORD");
                }
            }
            if(isUsed('Email', 'users', $email) && $email != $currentUser['Email']){
                $arrErrors[] = lang('EMAIL_USED_BEFORE');
            } else {
                if(strlen($email) > 100 || strlen($email) < 5){
                    $arrErrors[] = lang("EMAIL_MUST_BE_BETWEEN");
                }
                if(containsBadWord($email)){
                    $arrErrors[] = lang("EMAIL_CONTAINS_BAD_WORD");
                }
            }

            if(strlen($password) > 100 || strlen($password) < 5){
                $arrErrors[] = lang("PASSWORD_MUST_BE_BETWEEN");
            }

            if(strlen($fullName) > 100 || strlen($fullName) < 5){
                $arrErrors[] = lang("FULLNAME_MUST_BE_BETWEEN");
            }
            if(containsBadWord($fullName)){
                $arrErrors[] = lang("FULLNAME_CONTAINS_BAD_WORD");
            }
            if(empty($arrErrors)){
                $stmt = $db->prepare('UPDATE  
                                        users
                                    SET
                                        Username = ?,
                                        Email = ?,
                                        Password = ?,
                                        FullName = ?
                                    WHERE
                                        UserID = ?');
                $stmt->execute([$username, $email, $password, $fullName, $currentUser['UserID']]);
                header("Location: settings.php");
                exit();
            } else {?>
                <div class="container">
                    <?php foreach($arrErrors as $e) { ?>
                        <div class="alert alert-danger">
                            <?php echo $e ?>
                        </div>
            <?php   } ?>
                </div>
    <?php   }
        } ?>
        <div class="container">
            <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method='POST'>
                <div class="row gap-4 rtl-row-reverse">
                    <div class='col-sm-full col-lg-5'>
                        <div class="card">
                            <div class="card-header">
                                <?php echo lang("GENERAL_SETTINGS") ?>
                            </div>
                            <div class="card-body user-select-none">
                                <span class='d-block mb-3 w-100 rtl-align-right'><?php echo lang("EDIT_MY_ACCOUNT") ?></span>
                                <div class="d-flex gap-2 align-items-center mb-2 rtl-dir-rtl">
                                    <label for="userid" class='w-25'>
                                        <?php echo lang("ID_FIELD_FORM") ?>
                                    </label>
                                    <!-- See You HTML Hacker 😂😂 -->
                                    <input disabled type="text" name="userid" id="userid" value='<?php echo $currentUser['UserID'] ?>' class='w-75 op-z-p-3'>
                                </div>
                                <div class="d-flex gap-2 align-items-center mb-2 rtl-dir-rtl">
                                    <label for="username" class='w-25'>
                                        <?php echo lang("USERNAME_FIELD_FORM") ?>
                                    </label>
                                    <input type="text" name="username" id="username" placeholder='<?php echo lang("EMPTY_TO_NOT_CHANGE") ?>' value='<?php echo $currentUser['Username'] ?>' class='w-75'>
                                </div>
                                <div class="d-flex gap-2 align-items-center mb-2 rtl-dir-rtl">
                                    <label for="username" class='w-25'>
                                        <?php echo lang("EMAIL_FIELD_FORM") ?>
                                    </label>
                                    <input type="email" name="email" id="email" placeholder='<?php echo lang("EMPTY_TO_NOT_CHANGE") ?>' value='<?php echo $currentUser['Email'] ?>' class='w-75'>
                                </div>
                                <div class="d-flex gap-2 align-items-center mb-2 rtl-dir-rtl">
                                    <label for="password" class='w-25'>
                                        <?php echo lang("PASSWORD_FIELD") ?>
                                    </label>
                                    <input type="text" name="password" id="password" placeholder='<?php echo lang("EMPTY_TO_NOT_CHANGE") ?>' class='w-75'>
                                </div>
                                <div class="d-flex gap-2 align-items-center mb-5 rtl-dir-rtl">
                                    <label for="fullName" class='w-25'>
                                        <?php echo lang("FULLNAME_FIELD") ?>
                                    </label>
                                    <input type="text" name="fullName" id="fullName" placeholder='<?php echo lang("EMPTY_TO_NOT_CHANGE") ?>' value='<?php echo $currentUser['FullName'] ?>' class='w-75'>
                                </div>
                                <button data-url="settings.php?delete_account=(^_^;)" class='warningBtn text-danger reset-btn' data-warning='<?php echo lang("WANT_TO_DELETE_YOUR_ACCOUNT") ?>'>
                                    <?php echo lang('DELETE_MY_ACCOUNT') ?>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class='col-sm-full col-lg-5'>
                        <div class="card">
                            <div class="card-header w-full rtl-align-right">
                                <?php echo lang("APPEARANCE") ?>
                            </div>
                            <div class="card-body">
                                    <div class='w-50 d-flex justify-self-center rtl-row-reverse d-flex justify-content-between'>
                                        <?php echo lang("LANGUAGE") ?>
                                        <select name="lang" id='lang'>
                                            <?php foreach($langs as $key => $lang){ ?>
                                                <option <?php if($key==$_COOKIE['lang']) echo 'selected' ?> value='<?php echo $key ?>'><?php echo sharedlang(strtoupper($lang)) ?></option>
                                                <?php   } ?>
                                            </select>
                                        </div>
                                        <div class='w-50 justify-content-center justify-self-center mt-4'>
                                            <div class='d-flex justify-content-between rtl-row-reverse'>
                                                <label class='pointer' for="dark"><?php echo lang("DARK_THEME") ?></label>
                                                <input class='pointer' type="radio" name="theme" <?php  if($_COOKIE['theme'] == 'dark') echo "checked" ?> value='dark' id="dark">
                                            </div>
                                            <div class='d-flex justify-content-between rtl-row-reverse'>
                                                <label class='pointer' for='light' for="light"><?php echo lang("LIGHT_THEME") ?></label>
                                                <input class='pointer' type="radio"  <?php if($_COOKIE['theme'] == 'light') echo "checked" ?>  name="theme" value='light' id="light">
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <input type="submit" value='<?php echo lang("SAVE_CHANGES_BTN") ?>' class='mt-4'>
                </div>
            </form>
        </div>
    <?php
    } else { ?>
        <div class="alert alert-primary w-50 justify-self-center mt-150px text-center fw-bold">
            <?php echo lang("LOGIN_SIGN_UP_FIRST") ?>
            <br>
            <br>
            <a href="signup.php">
                <?php echo lang("LOGIN_SIGN_UP_BTN") ?>
            </a>
        </div>
<?php }
    include $tpls.'footer.inc'; 
    ob_end_flush();