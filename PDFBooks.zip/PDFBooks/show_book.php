<?php
    ob_start();
    session_start();
    $_SESSION['lastPage'] = basename($_SERVER['REQUEST_URI']);
    $navbar    = '';
    $pageTitle = 'Categories';
    include 'init.inc';
    $bookid = isset($_GET['bookid']) ? $_GET['bookid']:0;
    ?>
    <div class='container'>
    <?php
    if(isset($_GET['comment_task']) && $_GET['comment_task']=='edit_comment' && isset($_GET['commentid'])){
        $stmt = $db->prepare("SELECT 
                                * 
                            FROM 
                                Comments 
                            WHERE 
                                CommentID = ?
                            AND 
                                UserID = ?");
        $stmt->execute([$_GET['commentid'], $_SESSION['UserID']]);
        if($stmt->rowCount()){ 
            $comment=$stmt->fetch(PDO::FETCH_ASSOC);
        ?>  
        <form action="<?php echo $_SERVER['PHP_SELF'] ?>?bookid=<?php echo $bookid ?>&comment_task=edit_comment&commentid=<?php echo $comment['CommentID'] ?>" method='GET'>
            <input type="text" name='newComment' value='<?php echo $comment['Comment'] ?>'>
            <input type="submit">
        </form>
<?php   } else {
            echo lang('COMMENT_IS_NOT_AVAILABLE');
        }
    }
    if(isset($_GET['comment_task'])&&$_GET['comment_task']=='delete_comment' && isset($_GET['commentid'])){
        $stmt = $db->prepare("SELECT 
                                * 
                            FROM 
                                Comments 
                            WHERE 
                                CommentID = ?
                            AND 
                                UserID = ?");
        $stmt->execute([$_GET['commentid'], $_SESSION['UserID']]);
        if($stmt->rowCount()){
            $stmt = $db->prepare('DELETE FROM comments WHERE CommentID = ?');
            $stmt->execute([$_GET['commentid']]);
            echo lang('COMMENT_DELETED_SUCCESSFULLY');
        } else {
            echo lang('COMMENT_IS_NOT_AVAILABLE');
        }
    }
    if($_SERVER['REQUEST_METHOD']=='POST'){
        if(isset($_POST['Comment'])){
            $comment = $_POST['Comment'];
        } else {
            $comment = '';
        }

        $arrErrors = [];

        if($comment == ''){
            $arrErrors[] = lang("COMMENT_MUST_NOT_BE_EMPTY");
        } else {
            if(strlen($comment) > 600 || strlen($comment) < 5){
                $arrErrors[] = lang("COMMENT_MUST_BE_BETWEEN");
            }
            if(containsBadWord($comment)){
                $arrErrors[] = lang("COMMENT_CONTAINS_BAD_WORD");
            }
        }
        if(!empty($arrErrors)){
            foreach($arrErrors as $e) { ?>
                <div class="alert alert-danger">
                    <?php echo $e ?>
                </div>
    <?php   }
        } else {
            $stmt = $db->prepare("INSERT INTO
                                    comments(Comment, UserID, BookID, Date)
                                VALUES(:comment, :userid, :bookid, now())");
            $stmt->execute([
                'comment'   =>  $comment, 
                'userid'    =>  $_SESSION['UserID'], 
                'bookid'    =>  $bookid
            ]);
            echo lang('COMMENT_ADDED_SUCCESSFULLY');
            ?>
            <script>
                let textarea = document.getElementById('comment');
                textarea.textContent = '';
            </script>
            <?php
        }
    }
    ?>
        <?php
        if(isBookPresent($bookid)) { 
            $stmt = $db->prepare("SELECT 
                                    books.*,
                                    categories.Name AS CatName
                                FROM 
                                    books
                                INNER JOIN
                                    categories
                                ON
                                    categories.ID = books.CatID
                                WHERE 
                                    BookID = ?");
            $stmt->execute([$bookid]);
            $currentBook = $stmt->fetch(PDO::FETCH_ASSOC);
            ?>
            <div class="card"> 
                <div class="card-header d-flex justify-content-between placeholder-color user-select-none rtl-row-reverse">
                    <span>
                        #ID: <span class='text-danger'><?php echo $currentBook['BookID'] ?></span>
                    </span>
                    <span>
                        <?php echo $currentBook['Date'] ?>
                    </span>
                </div>
                <div class="card-body d-flex rtl-dir-rtl">
                    <div class="img-container w-25">
                        <img src="<?php echo $frontCoversContainerFolder.$currentBook['IMG_FrontCover'] ?>" alt="" class='w-100'>
                    </div>
                    <div class="text w-75 ps-3 pe-3">
                        <h3><?php echo '<span class="text-primary fw-bold">'.$currentBook['Name'] .'</span> - '. $currentBook['Author'] ?></h3>
                        <br>
                        <h5><?php echo $currentBook['Description'] ?></h5>
                        <?php echo lang("BOOK_LANG_FIELD").' <span class="text-primary fw-bold">'.$langs[$currentBook['Language']].'</span>' ?>
                        <br>
                        <?php echo lang("BOOK_CAT_FIELD") .'<span class="text-primary fw-bold"> '.$currentBook['CatName'].'</span>'?>
                        <br>
                        <br>
                        <br>
                        <a class='text-success hover-success' title='<?php echo lang('DOWNLOAD_THE_BOOK') ?>' href="admin/<?php echo $booksContainerFolder.'/'.$currentBook['PDF_File'] ?>" download>
                            <?php echo lang("DOWNLOAD_BTN") ?>
                        </a>
                    </div>
                </div>
            </div>
            <div class="card mt-5">
                <div class="card-header fw-bold">
                    <?php echo lang('COMMENTS') ?>
                </div>
                <div class="card-body">
                    <?php if($currentBook['AllowComments']) { ?>
                    <?php
                        $comments = getCommentsByBookID($bookid);
                        ?>
                        <form class='mb--3' action="<?php echo $_SERVER['PHP_SELF'] ?>?bookid=<?php echo $bookid ?>" method='POST'>
                            <div class="group-inp">
                                <textarea 
                                    type="text" 
                                    name="Comment" 
                                    id='comment'
                                    class='w-100'
                                    placeholder='<?php echo lang("ADD_COMMENT") ?>'
                                    required
                                    onKeyup='adjustHeight(this)'
                                ></textarea>
                            </div>
                            <?php if(isset($_SESSION['UserID'])){ ?>
                                    <input class='mt--3 mb-3 btn btn-primary btn-sm' type="submit" value="<?php echo lang("ADD_COMMENT_BTN") ?>">
                            <?php } else { ?>
                                    <a href="login.php" class='btn btn-primary'><?php echo lang("LOGIN_TO_COMMENT_BTN") ?></a>
                            <?php } ?>
                        </form>
                        <br>
                        <?php
                        if(!empty($comments)) {
                            foreach($comments as $comment) { ?>
                                <div class='d-flex justify-content-between rtl-row-reverse a-comment'>
                                    <div class='fs-12px d-flex gap-3 rtl-row-reverse w-75'>
                                        <span class='text-primary fw-bold user-select-none'>
                                            <?php echo $comment['Username'] ?>
                                        </span>
                                        <span class='w-75'>
                                            <?php echo $comment['Comment'] ?>
                                        </span>
                                    </div>
                                <?php if(isset($_SESSION['UserID']) && $_SESSION['UserID']==$comment['UserID']) { ?>
                                    <div class='control-btns'>
                                        <a href="show_book.php?bookid=<?php echo $bookid ?>&comment_task=edit_comment&commentid=<?php echo $comment['CommentID'] ?>" class='btn btn-info btn-sm'>
                                            <i class="fa-solid fa-pen fa-fw text-light"></i>
                                        </a>
                                        <button 
                                            class='warningBtn btn btn-danger btn-sm' 
                                            data-warning='<?php echo lang('WANT_TO_DELETE_COMMENT') ?>' 
                                            data-url='show_book.php?bookid=<?php echo $bookid ?>&comment_task=delete_comment&commentid=<?php echo $comment['CommentID'] ?>'
                                        >
                                        <i class="fa-solid fa-trash fa-fw"></i>
                                        </button>
                                    </div>
                                <?php } ?>
                                </div>
                <?php       } 
                        } else {
                            echo '<span class="fw-bold">'.lang('NO_COMMENTS_TO_SHOW').'</span>';
                        } ?>
                </div>
            <?php } else {
                        echo lang("COMMENTING_IS_NOT_ALLOWED");
                  } ?>
            </div>
            <?php
        ?>
<?php   } else { ?>
    <div class="alert alert-primary d-flex justify-content-center w-50 justify-self-center flex-dir-column text-center mt-150px rtl-dir-rtl">
        <p class='fw-bold'><?php echo lang("NO_BOOK_WITH_THIS_ID") ?></p>
        <div>
            <a class='btn btn-primary btn-sm' href="categories.php"><?php echo lang("SHOW_ALL_CATEGORIES") ?></a>
        </div>
    </div>
<?php   } ?>
    </div>
<?php
    include $tpls.'footer.inc';
    ob_end_flush();
