<?php
    session_start();
    ob_start();

    $pageTitle  =  'Users';
    $navbar     =  '';

    include 'init.inc';

    $_SESSION['lastPageAdmin'] = basename($_SERVER['REQUEST_URI']);
    
    if(!isset($_SESSION['AdminID'])) {
        addLog(1, 'a User Tried to Enter Users Section Without Logging in');
        header("Location: index.php");
        exit();
    }

    $userid = isset($_GET['userid']) && is_numeric($_GET['userid']) ? $_GET['userid'] : 0;

    $pages = ['Manage', 'Add', 'Insert', 'Delete', 'Edit', 'Update', 'Activate'];
    $page = isset($_GET['page']) && in_array($_GET['page'], $pages) ? $_GET['page'] : "Manage";
    $users = getAll("users");

    $currentUser = getSpecificFromAll('UserID', 'users', $userid);

    ?><div class="container">
    <?php 
    if($page=='Manage'){ 
        if(!empty($users)){ ?>
        <h1 class="section"><?php echo lang("MANAGE_USERS_SECTION") ?></h1>
        <div class="table-responsive">
            <table class="main-table table table-bordered text-center shadow-sm">
                <thead>
                    <th>#<?php echo lang("ID_TABLE_HEAD") ?></th>
                    <th><?php echo lang("USERNAME_TABLE_HEAD") ?></th>
                    <th><?php echo lang("EMAIL_TABLE_HEAD") ?></th>
                    <th><?php echo lang("FULLNAME_TABLE_HEAD") ?></th>
                    <th><?php echo lang("REG_DATE_TABLE_HEAD") ?></th>
                    <th><?php echo lang("CONTROL_TABLE_HEAD") ?></th>
                </thead>
                <tbody>
                    <?php
                        foreach($users as $user){
                    ?>
                    <tr>
                        <td><?php echo truncate($user['UserID'], 30) ?></td>
                        <td><?php echo truncate($user['Username'], 30) ?></td>
                        <td><?php echo truncate($user['Email'], 30) ?></td>
                        <td><?php echo truncate($user['FullName'], 30) ?></td>
                        <td><?php echo $user['Date'], 30 ?> </td>
                        <td class='user-select-none'>
                    <?php   if(!isAuthorizedToControlAdmin($_SESSION['AdminID']) && $user['GroupID'] == 1) {
                                echo '<span class="text-danger fw-bold user-select-none" title="'.lang("WHY_CONTROLLING_DENIED").'">'.lang("CONTROLLING_DENIED").'</span>';
                            } elseif($_SESSION['AdminID'] == $user['UserID']) { ?>
                                <div>
                                    <a 
                                        href='users.php?page=Edit&userid=<?php echo $user['UserID'] ?>' 
                                        class='btn btn-primary btn-sm'
                                        title='<?php echo lang("EDIT_THE_USER") ?>'
                                    >
                                        <i class="fa-solid fa-pen fa-fw"></i>
                                    </a>
                                    <button 
                                        class='btn btn-danger btn-sm warningBtn' 
                                        data-url='users.php?page=Delete&userid=<?php echo $user['UserID'] ?>'
                                        data-warning='<?php echo lang('WANT_TO_DELETE_YOUR_ACCOUNT') ?>'
                                        title='<?php echo lang("DELETE_THE_USER") ?>'
                                    >
                                        <i class='fa-solid fa-trash fa-fw'></i>
                                    </button>
                                </div>
                    <?php   }
                            else {
                                ?>
                                <div>
                                    <?php if(!$user['RegStatus']) { ?>
                                    <button 
                                        class='warningBtn btn btn-success btn-sm' 
                                        data-warning='<?php echo lang("WANT_TO_ACTIVATE_USER") ?>'
                                        data-url='users.php?page=Activate&userid=<?php echo $user['UserID'] ?>'
                                    >
                                        <i class="fa-solid fa-power-off fa-fw"></i>
                                    </button>
                                    <?php } ?>
                                    <a 
                                        href='users.php?page=Edit&userid=<?php echo $user['UserID'] ?>' 
                                        class='btn btn-primary btn-sm'
                                        title='<?php echo lang("EDIT_THE_USER") ?>'
                                    >
                                        <i class="fa-solid fa-pen fa-fw"></i>
                                    </a>
                                    <button 
                                        class='btn btn-danger btn-sm warningBtn' 
                                        data-url='users.php?page=Delete&userid=<?php echo $user['UserID'] ?>'
                                        data-warning='<?php echo lang('WANT_TO_DELETE_USER') ?>'
                                        title='<?php echo lang("DELETE_THE_USER") ?>'
                                    >
                                        <i class='fa-solid fa-trash fa-fw'></i>
                                    </button>
                                </div>
                        </td>
                    </tr>
                <?php   } }?>
                </tbody>
            </table>
        </div>
        <a href="users.php?page=Add" class='btn btn-primary btn-sm'>
            <?php echo lang("ADD_BTN") ?>
        </a>
<?php 
        }else { ?>
            <div class="alert alert-primary d-flex justify-content-center w-50 justify-self-center flex-dir-column text-center mt-150px">
                <p class='fw-bold'><?php echo lang("NO_USERS_TO_SHOW") ?></p>
                <div>
                    <a class='btn btn-primary btn-sm' href="users.php?page=Add"><?php echo lang("ADD_USER") ?></a>
                </div>
            </div>
<?php   }
    }elseif($page=='Add'){ ?>
        <h1 class='section'><?php echo lang("ADD_NEW_USER_SECTION") ?></h1>
        <form action="<?php echo $_SERVER['PHP_SELF'] ?>?page=Insert" method='POST'>
            <div class='group-inp contains-required-inp rtl-row-reverse'>
                <label 
                for="username"
                class='rtl-align-right rtl-dir-rtl'
                >
                <?php echo lang("USERNAME_FIELD")?>
                </label>
                <input 
                    type="text" 
                    name="username" 
                    id="username"
                    placeholder='<?php echo lang("BETWEEN_5_AND_100") ?>'
                    minlength='5'
                    maxlength='100'
                    required
                />
            </div>
            <div class='group-inp contains-required-inp rtl-row-reverse'>
                <label 
                for="password"
                class='rtl-align-right rtl-dir-rtl'
                >
                <?php echo lang("PASSWORD_FIELD")?>
            </label>
            <input 
            type="password" 
            name="password" 
            id="password"
            placeholder='<?php echo lang("BETWEEN_5_AND_100") ?>'
            minlength='8'
            maxlength='100'
            required
            />
        </div>
        <div class='group-inp contains-required-inp rtl-row-reverse'>
            <label 
            for="email"
            class='rtl-align-right rtl-dir-rtl'
            >
            <?php echo lang("EMAIL_FIELD")?>
                </label>
                <input 
                    type="text" 
                    name="email" 
                    id="email"
                    placeholder='<?php echo lang("BETWEEN_5_AND_100") ?>'
                    minlength='5'
                    maxlength='100'
                    required
                />
            </div>
            <div class='group-inp contains-required-inp rtl-row-reverse'>
                <label 
                for="fullName"
                class='rtl-align-right rtl-dir-rtl'
                >
                <?php echo lang("FULLNAME_FIELD")?>
                </label>
                <input 
                    type="text" 
                    name="fullName" 
                    id="fullName"
                    placeholder='<?php echo lang("BETWEEN_5_AND_100") ?>'
                    minlength='5'
                    maxlength='100'
                    required
                />
            </div>
            <input type="submit" value="<?php echo lang("ADD_BTN") ?>" class="btn btn-primary btn-sm">
            <button class="btn btn-danger back-btn btn-sm">
                <?php echo lang("BACK_BTN") ?>
            </button>
        </form>
<?php 
    }elseif($page=='Insert') {
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            if(!isset($_POST['username'])) {
                $username = '';
            } else {
                $username = trim(filter_var($_POST['username'], FILTER_SANITIZE_STRING));
            }

            if(!isset($_POST['password'])){
                $password = '';
            } else {
                $password = trim(filter_var($_POST['password'], FILTER_SANITIZE_STRING));
            }

            if(!isset($_POST['email'])){
                $email = '';
            } else {
                $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
            }

            if(!isset($_POST['fullName'])){
                $fullName = '';
            } else {
                $fullName = trim(filter_var($_POST['fullName'], FILTER_SANITIZE_STRING));
            }

            $arrErrors = [];

            if($username==''){
                $arrErrors[] = lang("USERNAME_MUST_NOT_BE_EMPTY");
            } else {
                if(isUsed("Username", 'Users', $username)){
                    $arrErrors[] = lang("USERNAME_USED_BEFORE");
                } else {
                    if(strlen($username) < 5 || strlen($username) > 100){
                        $arrErrors[] = lang("USERNAME_MUST_BE_BETWEEN");
                    }
                }
            }
            if($password==''){
                $arrErrors[] = lang("PASSWORD_MUST_NOT_BE_EMPTY");
            } else {
                if(strlen($password) < 8 || strlen($password) > 100){
                    $arrErrors[] = lang("PASSWORD_MUST_BE_BETWEEN");
                }
            }

            if($email==''){
                $arrErrors[] = lang("EMAIL_MUST_NOT_BE_EMPTY");
            } else {
                if(isUsed("Email", 'users', $email)) {
                    $arrErrors[] = lang("EMAIL_USED_BEFORE");
                } else {
                    if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        $arrErrors[] = lang("INVALID_EMAIL");
                    } else {
                        if(strlen($email) < 5 || strlen($email) > 100){
                            $arrErrors[] = lang("EMAIL_MUST_BE_BETWEEN");
                        }
                    }
                }
            }

            if($fullName ==''){
                $arrErrors[] = lang("FULLNAME_MUST_NOT_BE_EMPTY");
            } else {
                if(strlen($fullName) < 5 || strlen($fullName) > 100){
                    $arrErrors[] = lang("FULLNAME_MUST_BE_BETWEEN");
                }
            }
            if(!empty($arrErrors)){
                foreach($arrErrors as $e){ 
                    addLog(1, "Admin With ID ".$_SESSION['AdminID']." Tried to Insert User But Faced Some Errors on Validation");
                ?>
                    <div class="alert alert-danger fw-bold">
                        <?php echo $e ?>
                    </div>
        <?php   }?>
                <button class="btn btn-danger back-btn btn-sm">
                    <?php echo lang("BACK_BTN") ?>
                </button>
        <?php
            } else {
                $stmt = $db->prepare("INSERT INTO 
                                        users(Username, Password, Email, FullName, GroupID, RegStatus, Date)
                                        VALUES(:username, :password, :email, :fullName, 0, 1, now())");
                $stmt->execute([
                    'username'   =>  $username,
                    'password'   =>  sha1($password),
                    'email'      =>  $email,
                    'fullName'   =>  $fullName,
                ]); 
                if($stmt->rowCount()){
                    addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Added a User With Name "'.$username.'" Successfully');
                ?>
                    <div class="alert alert-success w-50 d-flex justify-self-center flex-dir-column justify-content-center align-items-center gap-2 mt-150px">
                        <strong><?php echo lang("USER_ADDED_SUCCESSFULLY") ?>!</strong>
                        <div>
                            <a class="btn btn-primary btn-sm" href='users.php?page=Manage'><?php echo lang("OKAY") ?>!</a>
                        </div>
                    </div>
        <?php   } else {
                addLog(4, 'Admin With ID '.$_SESSION['AdminID'].' Failed Unexpectedly to Insert User With Name "'.$username.'"');
                ?>
                    <div class="alert alert-warning justify-self-center">
                        <?php echo lang("SOMETHING_WENT_WRONG") ?>
                        <a href="dashboard.php"><?php echo lang("GO_BACK_TO_HOME") ?></a>
                    </div>
        <?php   } ?>
    <?php   }
        } else {
            header("Location: users.php?page=Add"); // You Wonna Hack Me But I am Treating You Kindly :)
        }
    } elseif($page=='Delete') {
        if(isUsed("UserID","users", $userid)) {
            $stmt = $db->prepare("DELETE FROM users WHERE UserID = ?");
            $stmt->execute([$userid]);
            if($stmt->rowCount()){
                addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Deleted User With ID '.$userid.' From Database Successfully');
                header("Location: users.php?page=Manage");
                exit();
            } else {
                addLog(4, 'Admin With ID '.$_SESSION['AdminID'].' Failed Unexpectedly To Delete User With ID '.$userid.' From Database');
                ?>
                    <div class="alert alert-warning justify-self-center">
                        <?php echo lang("SOMETHING_WENT_WRONG") ?>
                        <a href="dashboard.php"><?php echo lang("GO_BACK_TO_HOME") ?></a>
                    </div>
                <?php
            }
        } else { ?>
            <div class="alert alert-danger w-50 justify-self-center text-center mt-150px d-flex flex-dir-column">
                <strong><?php echo lang("NO_USER_WITH_THIS_ID") ?></strong>
                <div>
                    <a href="users.php?page=Manage" class='btn btn-danger btn-sm mt-2'>
                        <?php echo lang("BACK_BTN") ?>
                    </a>
                </div>
            </div>
<?php   }
    } elseif($page=='Edit') { ?>
        <h1 class='section'><?php echo lang("EDIT_USER_SECTION") ?></h1>
        <form action="<?php echo $_SERVER['PHP_SELF'] ?>?page=Update&userid=<?php echo $currentUser['UserID'] ?>" method='POST'>
            <div class='group-inp contains-required-inp rtl-row-reverse'>
                <label 
                for="name"
                class='rtl-align-right rtl-dir-rtl'
                >
                <?php echo lang("USERNAME_FIELD")?>
                </label>
                <input 
                    type         =  'text' 
                    name         =  'username' 
                    id           =  'name'
                    placeholder  =  '<?php echo $currentUser['Username'] ?>'
                    value        =  '<?php echo $currentUser['Username'] ?>'
                    minlength    =  '5'
                    maxlength    =  '100'
                    required
                />
            </div>
            <div class='group-inp contains-required-inp rtl-row-reverse'>
                <label 
                for="password"
                class='rtl-align-right rtl-dir-rtl'
                >
                <?php echo lang("PASSWORD_FIELD")?>
                </label>
                <input 
                    type         =  'password' 
                    name         =  'password' 
                    id           =  'password'
                    placeholder  =  '*******************'
                    minlength    =  '8'
                    maxlength    =  '100'
                />
            </div>
            <div class='group-inp contains-required-inp rtl-row-reverse'>
                <label 
                for="email"
                class='rtl-align-right rtl-dir-rtl'
                >
                <?php echo lang("EMAIL_FIELD")?>
                </label>
                <input 
                    type         =  'text' 
                    name         =  'email' 
                    id           =  'email'
                    placeholder  =  '<?php echo $currentUser['Email'] ?>'
                    value        =  '<?php echo $currentUser['Email'] ?>'
                    minlength    =  '5'
                    maxlength    =  '100'
                />
            </div>
            <div class='group-inp contains-required-inp rtl-row-reverse'>
                <label 
                for="fullName"
                class='rtl-align-right rtl-dir-rtl'
                >
                <?php echo lang("FULLNAME_FIELD")?>
                </label>
                <input 
                    type         =  'text' 
                    name         =  'fullName' 
                    id           =  'fullName'
                    value        =  '<?php echo $currentUser['FullName'] ?>'
                    placeholder  =  '<?php echo $currentUser['FullName'] ?>'
                    minlength    =  '5'
                    maxlength    =  '100'
                    required
                />
            </div>
            <input type="submit" value="<?php echo lang("UPDATE_BTN") ?>" class="btn btn-primary btn-sm">
            <button class="btn btn-danger back-btn btn-sm">
                <?php echo lang("BACK_BTN") ?>
            </button>
        </form>
<?php 
    } elseif($page=='Update'){
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            $arrErrors = [];

            if(!isset($_POST['username']) || $_POST['username'] == '' || $_POST['username'] == $currentUser['Username']){
                $username = $currentUser['Username'];
            } else {
                $username = $_POST['username'];

                if(isUsed("Username", 'Users', $username)){
                    $arrErrors[] = lang('USERNAME_USED_BEFORE');
                } else {
                    if(strlen($username) < 5 || strlen($username) > 100){
                        $arrErrors[] = lang('USERNAME_MUST_BE_BETWEEN');
                    }
                    if(containsBadWord($username)){
                        $arrErrors[] = lang('USERNAME_CONTAINS_BAD_WORDS');
                    }
                }
            }

            if(!isset($_POST['password']) || $_POST['password'] == ''){
                $hashedPass = $currentUser['Password'];
            } else {
                $password = $_POST['password'];
                if(strlen($password) < 8 || strlen($password) > 100){
                    $arrErrors[] = lang('PASSWORD_MUST_BE_BETWEEN');
                }
            }

            $hashedPass = isset($password) ? sha1($password) : $hashedPass;

            if(!isset($_POST['email']) || $_POST['email']=='' || $_POST['email'] == $currentUser['Email']){
                $email = $currentUser['Email'];
            } else {
                $email = $_POST['email'];

                if(strlen($email) < 5 || strlen($email) > 100){
                    $arrErrors[] = lang('EMAIL_MUST_BE_BETWEEN');
                }
                if(containsBadWord($email)){
                    $arrErrors[] = lang('EMAIL_CONTAINS_BAD_WORDS');
                }
            }

            if(!isset($_POST['fullName']) || $_POST['fullName']==''||$_POST['fullName'] == $currentUser['FullName']){
                $fullName = $currentUser['FullName'];
            } else {
                $fullName = $_POST['fullName'];

                if(strlen($fullName) < 8 || strlen($fullName) > 100){
                    $arrErrors[] = lang('FULLNAME_MUST_BE_BETWEEN');
                }
                if(containsBadWord($fullName)){
                    $arrErrors[] = lang('FULLNAME_CONTAINS_BAD_WORDS');
                }
            }

            if(!empty($arrErrors)){
                foreach($arrErrors as $e){
                    addLog(1, "Admin With ID ".$_SESSION['AdminID']." Tried to Edit User With ID $userid But Faced Some Errors on Validation");
                ?>
                    <div class="alert alert-danger fw-bold">
                        <?php echo $e ?>
                    </div>
        <?php   }?>
                <button class="btn btn-danger back-btn btn-sm">
                    <?php echo lang("BACK_BTN") ?>
                </button>
        <?php
            } else {
                    $stmt =$db->prepare("UPDATE 
                                            users 
                                        SET
                                            Username   =  ?,
                                            Password   =  ?,
                                            Email      =  ?,
                                            FullName   =  ?
                                        WHERE 
                                            UserID         =  ?");
                $stmt->execute([ $username, $hashedPass, $email, $fullName, $userid]); 
                addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Updated User With ID '.$userid.' Successfully');
                ?>
                <div class="alert alert-success w-50 d-flex justify-self-center flex-dir-column justify-content-center align-items-center gap-2 mt-150px">
                    <strong><?php echo lang("USER_UPDATED_SUCCESSFULLY") ?>!</strong>
                    <div>
                        <a class="btn btn-primary btn-sm" href='users.php?page=Manage'><?php echo lang("OKAY") ?>!</a>
                    </div>
                </div>
        <?php
            }
        } else {
            header("Location: users.php?page=Manage");
        }
    } elseif($page=='Activate') {
        if(isUsed("UserID", "users", $userid)) {
            $stmt = $db->prepare("UPDATE 
                                    users 
                                SET
                                    RegStatus = 1
                                WHERE
                                    UserID = ?");
            $stmt->execute([$userid]); 
            if($stmt->rowCount()){
                addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Activated User With ID '.$userid.' Successfully');
            ?>
            <div class="alert alert-success w-50 d-flex justify-self-center flex-dir-column justify-content-center align-items-center gap-2 mt-150px">
                <strong><?php echo lang("USER_ACTIVATED_SUCCESSFULLY") ?>!</strong>
                <div>
                    <a class="btn btn-primary btn-sm" href='users.php?page=Manage'><?php echo lang("OKAY") ?>!</a>
                </div>
            </div>
    <?php   } else {
                addLog(4, 'Admin With ID '.$_SESSION['AdminID'].' Failed Unexpectedly to Activate User With ID '.$userid);
        ?>     
                <div class="alert alert-warning justify-self-center">
                    <?php echo lang("SOMETHING_WENT_WRONG") ?>
                    <a href="dashboard.php"><?php echo lang("GO_BACK_TO_HOME") ?></a>
                </div>
<?php       }
        } else { ?>
            <div class="alert alert-danger w-50 justify-self-center text-center mt-150px d-flex flex-dir-column">
                <strong><?php echo lang("NO_USER_WITH_THIS_ID") ?></strong>
                <div>
                    <a href="users.php?page=Manage" class='btn btn-danger btn-sm mt-2'>
                        <?php echo lang("BACK_BTN") ?>
                    </a>
                </div>
            </div>
<?php   }
    }
    ?></div><?php
    include $tpls.'footer.inc';
    ob_end_flush();