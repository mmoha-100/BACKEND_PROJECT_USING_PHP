<?php 
    include 'init.inc';
    session_start(); 
    if(isset($_SESSION['AdminID'])){
        addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Logged Out');
        unset($_SESSION['AdminID']);
        header("Location: index.php");
        exit();
    } else {
        addLog(1,"a User Trying to Log Out But Doesn\'t Have ID in the Session");
        header('Location: index.php');
        exit();
    }