<?php 
    session_start();
    ob_start();

    include 'includes/vars/max_trails.inc';
    include 'includes/langs/en.inc';

    if(!isset($_COOKIE['blocked']) || !$_COOKIE['blocked']){
        header("Location: index.php");
        exit();
    } ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo lang("BLOCKED_USER") ?></title>
        <link rel="stylesheet" href="../shared_files/css/bootstrap.min.css">
    </head>
<body>
    <div class="container d-flex justify-content-center align-items-center" style="height: 100vh;">
        <div class="text-center">
            <div class="alert alert-danger" role="alert">
                <h4 class="fw-bold"><?php echo lang("ACCESS_DENIED") ?></h4>
                <p class='mb-2'><?php echo lang("WHY_BLOCKED_USER") ?>.</p>
                <p class='mb-0'><?php echo lang("HOW_TO_UNBLOCK") ?>.</p>
            </div>
            <a href="../index.php" class="btn btn-primary">Go Back to Home</a>
        </div>
    </div>
</body>
</html>
<?php ob_end_flush();