<?php
    session_start();
    ob_start();
    $pageTitle = 'Books';
    $navbar = '';
    
    include 'init.inc';
    
    $_SESSION['lastPageAdmin'] = basename($_SERVER['REQUEST_URI']);
    
    if(!isset($_SESSION['AdminID'])) {
        addLog(1, 'a User Tried to Enter Books Section Without Logging in');
        header("Location: index.php");
        exit();
    }

    $page = isset($_GET['page']) ? $_GET['page'] : 'Manage' ;

    $books = getAllBooks();
    $bookid = isset($_GET['bookid']) ? $_GET['bookid'] : 0;

    if(isUsed('BookID', 'books', $bookid)) { 
        $currentBook = getSpecificFromAll('BookID', 'books', $bookid);
    }
    
    ?><div class="container"><?php
    if($page=='Manage'){
        if(!empty($books)) { ?>
            <h1 class="section"><?php echo lang("MANAGE_BOOKS_SECTION") ?></h1>
            <div class="table-responsive">
                <table class='main-table table table-bordered text-center shadow-sm'>
                    <thead>
                        <th>#<?php echo lang("ID_TABLE_HEAD") ?></th>
                        <th><?php echo lang("COVER_TABLE_HEAD") ?></th>
                        <th><?php echo lang("NAME_TABLE_HEAD") ?></th>
                        <th><?php echo lang("CATEGORY_TABLE_HEAD") ?></th>
                        <th><?php echo lang("LANGUAGE_TABLE_HEAD") ?></th>
                        <th><?php echo lang("DESCRIPTION_TABLE_HEAD") ?></th>
                        <th><?php echo lang("COMMENTING_TABLE_HEAD") ?></th>
                        <th><?php echo lang("DATE_TABLE_HEAD") ?></th>
                        <th><?php echo lang("CONTROL_TABLE_HEAD") ?></th>
                    </thead>
                    <tbody>
                        <?php
                        foreach($books as $book){ ?>
                            <tr>
                                <td><?php echo $book['BookID'] ?></td>
                                <td class='front-cover-img-in-td'>
                                    <?php
                                    if(file_exists($frontCoversContainerFolder.$book['IMG_FrontCover'])){ ?>
                                        <img src="<?php echo $frontCoversContainerFolder.$book['IMG_FrontCover'] ?>">
                            <?php   }else{ ?>
                                        <i title='<?php echo lang("COVER_NOT_FOUND") ?>' class="fa-solid fa-question fa-fw"></i>
                            <?php   }
                                    ?>
                                </td>
                                <td
                                    title='<?php echo $book['Name'] ?>'
                                >
                                    <?php echo truncate($book['Name'], 30) ?>
                                </td>
                                <td
                                    title='<?php echo $book['CatName'] ?>'
                                >
                                    <?php echo truncate($book['CatName'], 30) ?>
                                </td>
                                <td>
                                    <?php echo $langs[$book['Language']] ?>
                                </td>
                                <td 
                                    title='<?php echo $book['Description'] ?>'
                                >
                                    <?php echo truncate($book['Description'], 30) ?>
                                </td>
                                <td>
                                    <?php 
                                        echo $book['AllowComments'] ? '<span class="yes">'.lang("YES").'</span>':'<span class="no">'.lang("NO").'</span>';
                                    ?>
                                </td>
                                <td>
                                    <?php echo $book['Date'] ?>
                                </td>
                                <td class='user-select-none'>
                                    <?php if(!$book['Approved']) { ?>
                                    <button
                                        class='warningBtn btn btn-success btn-sm'
                                        data-url='books.php?page=Approve&bookid=<?php echo $book['BookID'] ?>'
                                        data-warning='<?php echo lang("WANT_TO_APPROVE_THE_BOOK") ?>'
                                        title='<?php echo lang('APPROVE_THE_BOOK') ?>'
                                    ><i class="fa-solid fa-power-off fa-fw"></i></button>
                                    <?php } ?>
                                    <a 
                                        class='btn btn-primary btn-sm'
                                        href="books.php?page=Edit&bookid=<?php echo $book['BookID'] ?>"
                                        title='<?php echo lang("EDIT_THE_BOOK") ?>'
                                    >
                                        <i class="fa-solid fa-pen"></i>
                                    </a>
                                    <button 
                                        class='warningBtn btn btn-danger btn-sm' 
                                        data-url='books.php?page=Delete&bookid=<?php echo $book['BookID'] ?>'
                                        data-warning='<?php echo lang("WANT_TO_DELETE_BOOK") ?>'
                                        title='<?php echo lang("DELETE_THE_BOOK") ?>'
                                    >
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                    <?php
                                    if(file_exists($booksContainerFolder.$book['PDF_File'])){?>
                                        <a 
                                            href='<?php echo $booksContainerFolder.$book['PDF_File'] ?>' 
                                            class='btn btn-secondary btn-sm' 
                                            title='<?php echo lang("DOWNLOAD_THE_BOOK") ?>'
                                            download
                                        >
                                            <i class="fa-solid fa-arrow-down"></i>
                                        </a>
                            <?php   } else { ?>
                                        <a 
                                            class='btn btn-danger op-z-p-3 btn-sm not-allowed'
                                            title='<?php echo lang("BOOK_FILE_NOT_EXISTS") ?>'
                                        >
                                            <i class="fa-solid fa-arrow-down"></i>
                                        </a>
                            <?php   }
                                    ?>
                                </td>
                            </tr>
                <?php   }
                        ?>
                    </tbody>
                </table>
            </div>
            <a href="books.php?page=Add" class='btn btn-primary btn-sm'>
                <?php echo lang("ADD_BTN") ?>
            </a>
<?php
        } else { ?>
            <div class="alert alert-primary d-flex justify-content-center w-50 justify-self-center flex-dir-column text-center mt-150px rtl-dir-rtl">
                <p class='fw-bold'><?php echo lang("NO_BOOKS_TO_SHOW") ?></p>
                <div>
                    <a class='btn btn-primary btn-sm' href="books.php?page=Add"><?php echo lang("ADD_BOOK") ?></a>
                </div>
            </div>
    <?php   
        }
    } elseif($page=='Add') { ?>
        <h1 class='section'><?php echo lang("ADD_NEW_BOOK_SECTION") ?></h1>
        <div class="cover-container" id='coverImgContainer'></div>
        <form action="<?php echo $_SERVER['PHP_SELF'] ?>?page=Insert" method='POST' enctype='multipart/form-data'>
            <div class='group-inp contains-required-inp rtl-row-reverse'>
                <label class='rtl-dir-rtl'>
                <?php echo lang("BOOK_LANG_FIELD")?>
                </label>
                <select name="lang" id="lang">
                    <?php
                        foreach($langs as $key => $lang){ ?>
                            <option value="<?php echo $key ?>"><?php echo $lang ?></option>
                <?php   } ?>
                </select>
            </div>
            <div class='group-inp contains-required-inp rtl-row-reverse'>
                <label class='rtl-dir-rtl'>
                <?php echo lang("BOOK_CAT_FIELD")?>
                </label>
                <select name="catid" id="catid">
                    <?php
                        $stmt = $db->prepare("SELECT * FROM categories");
                        $stmt->execute();
                        $cats = $stmt->fetchAll();
                        foreach($cats as $cat){ ?>
                            <option value="<?php echo $cat['ID'] ?>"><?php echo $cat['Name'] ?></option>
                <?php   } ?>
                </select>
            </div>
            <div class='group-inp contains-required-inp rtl-row-reverse'>
                <label 
                for="bookName"
                class='rtl-dir-rtl'
                >
                <?php echo lang("BOOK_NAME_FIELD")?>
                </label>
                <input 
                    type="text" 
                    name="bookName"
                    id="bookName"
                    placeholder='<?php echo lang("BETWEEN_5_AND_100") ?>'
                    minlength='5'
                    maxlength='100'
                    required
                />
            </div>
            <div class='group-inp contains-required-inp rtl-row-reverse'>
                <label 
                    for="bookDescription"
                    class='rtl-dir-rtl'
                >
                    <?php echo lang("CATEGORY_DESCRIPTION_FIELD_FORM")?>
                </label>
                <textarea 
                    type="text" 
                    name="bookDescription" 
                    id="bookDescription"
                    required
                    onKeyup='adjustHeight(this)'
                    placeholder='<?php echo lang("BETWEEN_8_AND_600") ?>'
                ></textarea>
            </div>
            <div class='group-inp contains-required-inp rtl-row-reverse'>
                <label 
                for="bookAuthor"
                class='rtl-dir-rtl'
                >
                <?php echo lang("BOOK_AUTHOR_NAME_FIELD")?>
                </label>
                <input 
                    type="text"
                    name="bookAuthor" 
                    id="bookAuthor"
                    placeholder='<?php echo lang("BETWEEN_5_AND_100") ?>'
                    minlength='5'
                    maxlength='100'
                    required
                />
            </div>
            <div class='group-inp contains-required-inp rtl-row-reverse'>
                <label 
                    for="pdfBookFile"
                    class='rtl-dir-rtl'
                >
                <?php echo lang("BOOK_PDF_FILE_FIELD")?>
                </label>
                <div>
                    <label for="pdfBookFile" class='w-100 btn btn-success btn-sm'>
                        <?php echo lang("UPLOAD_BTN") ?>
                    </label>
                </div>
                <input 
                    type="file" 
                    class='d-none'
                    name="pdfBookFile" 
                    id="pdfBookFile"
                />
            </div>
            <div class='group-inp contains-required-inp rtl-row-reverse'>
                <label 
                    for="frontCoverBookImg"
                    class='rtl-dir-rtl'
                >
                <?php echo lang("BOOK_COVER_IMG_FIELD")?>
                </label>
                <div>
                    <label for="frontCoverBookImg" class='w-100 btn btn-success btn-sm rtl-dir-rtl'>
                        <?php echo lang("UPLOAD_BTN") ?>
                    </label>
                </div>
                <input 
                    type="file" 
                    class='d-none'
                    name="frontCoverBookImg" 
                    id="frontCoverBookImg"
                />
            </div>
            <input type="submit" value="<?php echo lang("ADD_BTN") ?>" class="btn btn-primary btn-sms">
            <button class="btn btn-danger back-btn btn-sm">
                <?php echo lang("BACK_BTN") ?>
            </button>
        </form>
<?php
    } elseif($page=='Insert') {
        if($_SERVER['REQUEST_METHOD']=='POST') {
            $arrErrors = [];

            if(isset($_POST['catid'])) {
                $catid = $_POST['catid'];
            } else {
                $catid = 0;
            }

            if(isset($_POST['bookName'])){
                $bookName = trim(filter_var($_POST['bookName'], FILTER_SANITIZE_STRING));
            } else {
                $bookName = '';
            }

            if(isset($_POST['bookDescription'])){
                $bookDescription = trim(filter_var($_POST['bookDescription'], FILTER_SANITIZE_STRING));
            } else {
                $bookDescription = '';
            }

            if(isset($_POST['bookAuthor'])){
                $bookAuthor = trim(filter_var($_POST['bookAuthor'], FILTER_SANITIZE_STRING));
            } else {
                $bookAuthor = '';
            }

            if(isset($_POST['lang'])){
                $lang = $_POST['lang'];
            } else {
                $lang = 'en';
            }

            if(!array_key_exists($lang, $langs)) { // $langs => in init.inc
                $lang = 'en';
            }

            if(!isUsed("ID", "categories", $catid)){
                $arrErrors[] = lang("NO_CAT_WITH_THIS_ID");
            }

            if($bookName == ''){
                $arrErrors[] = lang("BOOK_NAME_MUST_NOT_BE_EMPTY");
            } else {
                if(isUsed('Name', 'Books', $bookName)){
                    $arrErrors[] = lang('BOOK_NAME_USED_BEFORE');
                }
                if(strlen($bookName) > 100 || strlen($bookName) < 5){
                    $arrErrors[] = lang("BOOK_NAME_MUST_BE_BETWEEN");
                }
                if(containsBadWord($bookName)){ 
                    $arrErrors[] = lang("BOOK_NAME_CONTAINS_BAD_WORDS");
                }
            }

            if($bookDescription == ''){
                $arrErrors[] = lang("BOOK_DESCRIPTION_MUST_NOT_BE_EMPTY");
            }else{
                if(strlen($bookDescription) > 600 || strlen($bookDescription) < 8){
                    $arrErrors[] = lang("BOOK_DESCRIPTION_MUST_BE_BETWEEN");
                }
                if(containsBadWord($bookDescription)){ 
                    $arrErrors[] = lang("BOOK_DESCRIPTION_CONTAINS_BAD_WORDS");
                }
            }

            if($bookAuthor == '') {
                $arrErrors[] = lang("BOOK_AUTHOR_NAME_MUST_NOT_BE_EMPTY");
            } else {
                if(strlen($bookAuthor) > 100 || strlen($bookAuthor) < 5){
                    $arrErrors[] = lang("BOOK_AUTHOR_NAME_MUST_BE_BETWEEN");
                }
                if(containsBadWord($bookAuthor)){ 
                    $arrErrors[] = lang("BOOK_AUTHOR_NAME_CONTAINS_BAD_WORDS");
                }
            }

            // Files Validations:
            $maxSize             = MegaToByte(20);
            if(isset($_FILES['pdfBookFile'])){
                $pdfBook =  $_FILES['pdfBookFile'];
            }else{
                $pdfBook = ['size'=>'','name'=>'','tmp_name'=>''];
            }
            if(isset($_FILES['frontCoverBookImg'])){
                $frontCoverBookImg   =  $_FILES['frontCoverBookImg'];
            } else {
                $frontCoverBookImg = ['size'=>'','name'=>'','tmp_name'=>''];
            }
            
                //PDF Book:
            $bookSize = $pdfBook['size'];
            $bookFileName = $pdfBook['name'];
            $bookTmp  = $pdfBook['tmp_name'];

            if($bookFileName == ''){
                $arrErrors[] = lang('PDF_BOOK_REQUIRED');
            } else {
                $bookExtension = explode('.', $bookFileName);
                $bookExtension  = strtolower(end($bookExtension));

                if($bookSize > $maxSize){
                    $arrErrors[] = lang('BOOK_SIZE_ERROR');
                }
                if($bookExtension !== 'pdf'){
                    $arrErrors[] = lang('BOOK_EXTENSION_MUST_BE_PDF');
                }
                $validBookFileName = validName($booksContainerFolder, $bookFileName);
            }
            
            $maxSize  = MegaToByte(10);

                // Front Cover:
            $coverSize = $frontCoverBookImg['size'];
            $coverName = $frontCoverBookImg['name'];
            $coverTmp  = $frontCoverBookImg['tmp_name'];

            if($coverName==''){
                $arrErrors[] = lang('COVER_OF_BOOK_REQUIRED');
            } else {
                $imgsExtensions      = ['png', 'jpg', 'jpeg'];
                $coverExtension = explode('.', $coverName);
                $coverExtension  = strtolower(end($coverExtension));

                if($coverSize > $maxSize){
                    $arrErrors[] = lang('BOOK_COVER_SIZE_ERROR');
                }
                if(!in_array($coverExtension, $imgsExtensions)){
                    $arrErrors[] = lang('COVER_EXTENSION_ERROR');
                }
                $validFrontCoverName = validName($frontCoversContainerFolder, $coverName);
            }


            if(empty($arrErrors)) {
                if(isUsed('PDF_File', 'books', $validBookFileName)){
                    $validBookFileName = validName($booksContainerFolder, $validBookFileName);
                }
                if(isUsed('IMG_FrontCover', 'books', $validFrontCoverName)){
                    $validFrontCoverName = validName($frontCoversContainerFolder, $validFrontCoverName);
                }

                move_uploaded_file($bookTmp, $booksContainerFolder.$validBookFileName);
                move_uploaded_file($coverTmp, $frontCoversContainerFolder.$validFrontCoverName);

                $stmt = $db->prepare("INSERT INTO
                                books(Language, Name, Description, PDF_File, IMG_FrontCover, Author, Approved, Date, CatID)
                            VALUES
                                (:lang, :name, :description, :pdf_file, :front_cover, :author, 1, now(), :catid)");
                $stmt->execute([
                    'lang'          =>      $lang,
                    'name'          =>      $bookName,
                    'description'   =>      $bookDescription,
                    'pdf_file'      =>      $validBookFileName,
                    'front_cover'   =>      $validFrontCoverName,
                    'author'        =>      $bookAuthor,
                    'catid'         =>      $catid,
                ]); 
                    if($stmt->rowCount()){ 
                        addLog(1, 'User With ID '.$_SESSION['AdminID'].' Added a Book With Name '.$bookName.' Successfully');
                    ?>
                        <div class="alert alert-success w-50 d-flex justify-self-center flex-dir-column justify-content-center align-items-center gap-2 mt-150px rtl-dir-rtl">
                            <strong><?php echo lang("BOOK_ADDED_SUCCESSFULLY") ?>!</strong>
                            <div>
                                <a class="btn btn-primary btn-sm" href='books.php?page=Manage'><?php echo lang("OKAY") ?>!</a>
                            </div>
                        </div>
            <?php   } else { 
                        addLog(4, 'User With ID '.$_SESSION['AdminID'].' Failed Unexpectedly to Insert Book With Name '.$bookName);
                        ?>
                        <div class="alert alert-warning justify-self-center rtl-dir-rtl">
                            <?php echo lang("SOMETHING_WENT_WRONG") ?>
                            <a href="dashboard.php"><?php echo lang("GO_BACK_TO_HOME") ?></a>
                        </div>
<?php               } ?>
        <?php   } else {
                    addLog(1, "Admin With ID ".$_SESSION['AdminID']." Tried to Add Book But Faced Some Errors on Validation");
                foreach($arrErrors as $e) {                     
                    ?>
                    <div class="alert alert-danger justify-self-center w-50 text-center fw-bold mt-3 rtl-dir-rtl">
                        <?php echo $e ?>
                    </div>
<?php           }
            }
        } else {
            header("Location: books.php?page=Manage"); // Still Kind -_-
        }
    } elseif($page=='Delete') {
        if(isUsed("BookID", "books", $bookid)){
            // Removing Files From 'uploads' Folder:
            $stmt = $db->prepare('SELECT 
                                    IMG_FrontCover,
                                    PDF_File
                                FROM
                                    books
                                WHERE 
                                    BookID = ?');
            $stmt->execute([$bookid]);

            $wantedFiles = $stmt->fetch(PDO::FETCH_ASSOC);

            $bookFile        =  $frontCoversContainerFolder.$wantedFiles['IMG_FrontCover'];
            $frontCoverFile  =  $booksContainerFolder.$wantedFiles['PDF_File'];

            if(file_exists($bookFile)){
                if(unlink($bookFile)){
                    addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Deleted PDF File for Book With ID '.$bookid.' While Deleting the Book Successfully');
                } else {
                    addLog(4, 'Admin With ID '.$_SESSION['AdminID'].' Failed Unexpectedly To Delete PDF File for Book With ID '.$bookid.' While Deleting the Book');
                }
            }

            if(file_exists($frontCoverFile)){
                if(unlink($frontCoverFile)){
                    addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Deleted Front Cover Image for Book With ID '.$bookid.' While Deleting the Book Successfully');
                } else {
                    addLog(4, 'Admin With ID '.$_SESSION['AdminID'].' Failed Unexpectedly To Delete Front Cover Image for Book With ID '.$bookid .' While Deleting the Book');
                }
            }

            // Removing Records From Database:
            $stmt = $db->prepare("DELETE FROM books WHERE BookID = ?");
            $stmt->execute([$bookid]);
            if($stmt->rowCount()){
                addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Deleted Book With ID '.$bookid.' From Database Successfully');
                header("Location: books.php?page=Manage");
                exit();
            }else{
                addLog(4, 'Admin With ID '.$_SESSION['AdminID'].' Failed Unexpectedly to Delete Book With ID '.$bookid.' From Database');
                ?>
                    <div class="alert alert-warning justify-self-center rtl-dir-rtl">
                        <?php echo lang("SOMETHING_WENT_WRONG") ?>
                        <a href="dashboard.php"><?php echo lang("GO_BACK_TO_HOME") ?></a>
                    </div>
                <?php
            }
        } else { 
            ?>
            <div class="alert alert-danger w-50 justify-self-center text-center mt-150px d-flex flex-dir-column rtl-dir-rtl">
                <strong><?php echo lang("NO_BOOK_WITH_THIS_ID") ?></strong>
                <div>
                    <a href="books.php?page=Manage" class='btn btn-danger btn-sm mt-2'>
                        <?php echo lang("BACK_BTN") ?>
                    </a>
                </div>
            </div>
<?php   }
    } elseif($page=='Edit') { 
        if(isUsed('BookID', 'books', $bookid)) { 
            ?>
            <h1 class='section'><?php echo lang("EDIT_BOOK_SECTION") ?></h1>
            <div class="imgs">
                <span><?php echo lang("OLD_COVER") ?></span>
                <div class="cover-container">
                    <img src="<?php echo $frontCoversContainerFolder.$currentBook['IMG_FrontCover'] ?>" alt="">
                </div>
                <span><?php echo lang("NEW_COVER") ?></span>
                <div class="cover-container" id='coverImgContainer'>
                </div>
            </div>
            <form action="<?php echo $_SERVER['PHP_SELF'] ?>?page=Update&bookid=<?php echo $bookid ?>" method='POST' enctype='multipart/form-data'>
                <div class='group-inp contains-required-inp rtl-row-reverse'>
                    <label class='rtl-dir-rtl'>
                    <?php echo lang("BOOK_LANG_FIELD")?>
                    </label>
                    <select name="lang" id="lang">
                        <?php
                            foreach($langs as $key => $lang){ ?>
                                <option <?php if($currentBook['Language']==$key) echo 'selected' ?> value="<?php echo $key ?>"><?php echo $lang ?></option>
                    <?php   } ?>
                    </select>
                </div>
                <div class='group-inp contains-required-inp rtl-row-reverse'>
                    <label class='rtl-dir-rtl'>
                    <?php echo lang("BOOK_CAT_FIELD")?>
                    </label>
                    <select name="catid" id="catid">
                        <?php
                            $stmt = $db->prepare("SELECT * FROM categories");
                            $stmt->execute();
                            $cats = $stmt->fetchAll();
                            foreach($cats as $cat){ ?>
                                <option <?php if($currentBook['CatID']==$cat['ID']) echo 'selected' ?> value="<?php echo $cat['ID'] ?>"><?php echo $cat['Name'] ?></option>
                    <?php   } ?>
                    </select>
                </div>
                <div class='group-inp contains-required-inp rtl-row-reverse'>
                    <label 
                    for="bookName"
                    class='rtl-dir-rtl'
                    >
                    <?php echo lang("BOOK_NAME_FIELD")?>
                    </label>
                    <input 
                        type="text" 
                        name="bookName"
                        id="bookName"
                        placeholder='<?php echo lang("BETWEEN_5_AND_100") ?>'
                        minlength='5'
                        maxlength='100'
                        required
                        value='<?php echo $currentBook['Name'] ?>'
                    />
                </div>
                <div class='group-inp contains-required-inp rtl-row-reverse'>
                    <label 
                        for="bookDescription"
                        class='rtl-dir-rtl'
                    >
                        <?php echo lang("CATEGORY_DESCRIPTION_FIELD_FORM")?>
                    </label>
                    <textarea 
                        type="text" 
                        name="bookDescription" 
                        id="bookDescription"
                        required
                        onKeyup='adjustHeight(this)'
                        placeholder='<?php echo lang("BETWEEN_8_AND_600") ?>'
                    ><?php echo $currentBook['Description'] ?></textarea>
                </div>
                <div class='group-inp contains-required-inp rtl-row-reverse'>
                    <label 
                    for="bookAuthor"
                    class='rtl-dir-rtl'
                    >
                    <?php echo lang("BOOK_AUTHOR_NAME_FIELD")?>
                    </label>
                    <input 
                        type="text"
                        name="bookAuthor" 
                        id="bookAuthor"
                        placeholder='<?php echo lang("BETWEEN_5_AND_100") ?>'
                        minlength='5'
                        maxlength='100'
                        value='<?php echo $currentBook['Author'] ?>'
                        required
                    />
                </div>
                <div class='group-inp d-flex contains-required-inp rtl-row-reverse'>
                    <label class='rtl-dir-rtl'>
                        <?php echo lang("BOOKS_ALLOW_COMMENTS_FIELD_FORM")?>
                    </label>
                        <div class="radio-inp-group rtl-row-reverse">
                        <div>
                            <label for="allowed"><?php echo lang("YES")?></label>
                            <input 
                                type="radio" 
                                name="allowComments"
                                id="allowed"
                                value='1'
                                required
                                <?php
                                    if($currentBook['AllowComments']){
                                        echo 'checked';
                                    }
                                ?>
                            />
                        </div>
                        <div>
                            <label for="not-allowed"><?php echo lang("NO")?></label>
                            <input 
                                type="radio" 
                                name="allowComments"
                                id="not-allowed"
                                value='0'
                                required
                                <?php
                                    if(!$currentBook['AllowComments']){
                                        echo 'checked';
                                    }
                                ?>
                            />
                        </div>
                    </div>
                </div>
                <div class='group-inp contains-required-inp rtl-row-reverse'>
                    <label 
                        for="pdfBookFile"
                        class='rtl-dir-rtl'
                    >
                    <?php echo lang("BOOK_PDF_FILE_FIELD")?>
                    </label>
                    <div>
                        <label for="pdfBookFile" class='w-100 btn btn-success btn-sm'>
                            <?php echo lang("UPLOAD_BTN") ?>
                        </label>
                    </div>
                    <input 
                        type="file" 
                        class='d-none'
                        name="pdfBookFile" 
                        id="pdfBookFile"
                    />
                </div>
                <div class='group-inp contains-required-inp rtl-row-reverse'>
                    <label 
                        for="frontCoverBookImg"
                        class='rtl-dir-rtl'
                    >
                    <?php echo lang("BOOK_COVER_IMG_FIELD")?>
                    </label>
                    <div>
                        <label for="frontCoverBookImg" class='w-100 btn btn-success btn-sm'>
                            <?php echo lang("UPLOAD_BTN") ?>
                        </label>
                    </div>
                    <input 
                        type="file" 
                        class='d-none'
                        name="frontCoverBookImg" 
                        id="frontCoverBookImg"
                    />
                </div>
                <input type="submit" value="<?php echo lang("UPDATE_BTN") ?>" class="btn btn-primary btn-sm">
                <button class="btn btn-danger back-btn btn-sm">
                    <?php echo lang("BACK_BTN") ?>
                </button>
            </form>
<?php   } else { ?>
            <div class="alert alert-danger w-50 justify-self-center text-center mt-150px d-flex flex-dir-column rtl-dir-rtl">
                <strong><?php echo lang("NO_BOOK_WITH_THIS_ID") ?></strong>
                <div>
                    <a href="books.php?page=Manage" class='btn btn-danger btn-sm mt-2'>
                        <?php echo lang("BACK_BTN") ?>
                    </a>
                </div>
            </div>
<?php   }
        ?>
<?php 
    } elseif($page=='Update') { 
        if($_SERVER['REQUEST_METHOD']=='POST'){
            $arrErrors = [];

            addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' is Trying to Edit Book With ID '.$bookid);

            // Text Validations:
            if(isset($_POST['bookName'])){
                $bookName =   trim($_POST['bookName']);
            } else {
                $bookName = $currentBook['Name'];
            }

            if(isset($_POST['bookDescription'])){
                $bookDescription = trim($_POST['bookDescription']);
            } else {
                $bookDescription = $currentBook['Description'];
            }

            if(isset($_POST['bookAuthor'])){
                $bookAuthor  =  trim($_POST['bookAuthor']);
            } else {
                $bookAuthor  = $currentBook['Author'];
            }
            
            if(isset($_POST['catid'])){
                $bookCatid = $_POST['catid'];
            } else {
                $bookCatid = $currentBook['CatID'];
            }

            if(isset($_POST['lang'])) {
                $bookLanguage = $_POST['lang'];
            } else {
                $bookLanguage = $currentBook['Language'];
            }

            if(isset($_POST['allowComments']) && is_numeric($_POST['allowComments']) && ($_POST['allowComments']==1 || $_POST['allowComments']==0)){
                $allowComments = $_POST['allowComments'];
            } else {
                $allowComments = $currentBook['AllowComments'];
            }
            
            if($bookName == ''){
                $arrErrors[] = lang('BOOK_NAME_MUST_NOT_BE_EMPTY');
            } else {
                if($bookName !=$currentBook['Name'] && isUsed('Name', 'books', $bookName)){
                    $arrErrors[] = lang('BOOK_NAME_USED_BEFORE');
                }
                if(strlen($bookName) > 100 || strlen($bookName) < 5){
                    $arrErrors[] = lang("BOOK_NAME_MUST_BE_BETWEEN");
                }
                if(containsBadWord($bookName)){
                    $arrErrors[] = lang("BOOK_NAME_CONTAINS_BAD_WORDS");
                }
            }
            
            if(!isUsed('ID', 'categories', $bookCatid)){
                $arrErrors[] = lang('NO_CAT_WITH_THIS_ID');
            }
            
            if(!array_key_exists($bookLanguage, $langs)){
                $arrErrors[] = lang("NOT_SUPPORTED_LANGUAGE");
            }
            if($bookDescription ==''){
                $arrErrors[] = lang("BOOK_DESCRIPTION_MUST_NOT_BE_EMPTY");
            } else {
                if(strlen($bookDescription) > 600 || strlen($bookDescription) < 8){
                    $arrErrors[] = lang("BOOK_DESCRIPTION_MUST_BE_BETWEEN");
                }
                if(containsBadWord($bookDescription)){
                    $arrErrors[] = lang("BOOK_DESCRIPTION_CONTAINS_BAD_WORDS");
                }
            }

            #################################################################################################
            #################################################################################################

            // Files Validations:
            if(isset($_FILES['pdfBookFile'])){
                $pdfBook             =  $_FILES['pdfBookFile'];
            }else{
                $pdfBook = ['size'=>'','name'=>'','tmp_name'=>''];
            }

            if(isset($_FILES['frontCoverBookImg'])){
                $frontCoverBookImg   =  $_FILES['frontCoverBookImg'];
            } else {
                $frontCoverBookImg = ['size'=>'','name'=>'','tmp_name'=>''];
            }

            $maxSize  = MegaToByte(20);
                //PDF Book:
            $bookSize = $pdfBook['size'];
            $bookFileName = $pdfBook['name'];
            $bookTmp  = $pdfBook['tmp_name'];

            if($bookFileName == ''){
                $prevFileName = true;
            } else {
                $bookExtension = explode('.', $bookFileName);
                $bookExtension  = strtolower(end($bookExtension));

                if($bookSize > $maxSize){
                    $arrErrors[] = lang('BOOK_SIZE_ERROR');
                }
                if($bookExtension !== 'pdf'){
                    $arrErrors[] = lang('BOOK_EXTENSION_MUST_BE_PDF');
                }
                $validBookFileName = validName($booksContainerFolder, $bookFileName);
            }
            
            
            $maxSize  = MegaToByte(10);

                // Front Cover:
            $coverSize = $frontCoverBookImg['size'];
            $coverName = $frontCoverBookImg['name'];
            $coverTmp  = $frontCoverBookImg['tmp_name'];

            if($coverName==''){
                $prevCover = true;
            } else {
                $imgsExtensions      = ['png', 'jpg', 'jpeg'];
                $coverExtension = explode('.', $coverName);
                $coverExtension  = strtolower(end($coverExtension));

                if($coverSize > $maxSize){
                    $arrErrors[] = lang('BOOK_COVER_SIZE_ERROR');
                }
                if(!in_array($coverExtension, $imgsExtensions)){
                    $arrErrors[] = lang('COVER_EXTENSION_ERROR');
                }
                $validFrontCoverName = validName($frontCoversContainerFolder, $coverName);
            }


            if(empty($arrErrors)) {
                if(isset($prevFileName)) {
                    $validBookFileName  = $currentBook['PDF_File'];
                } else {
                    // Delete the Previous Files(Book PDF File)
                    if(file_exists($booksContainerFolder.$currentBook['PDF_File'])){
                        if(unlink($booksContainerFolder.$currentBook['PDF_File'])){
                            addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Deleted PDF File for Book With ID '.$bookid.' While Updating Successfully');
                        } else {
                            addLog(4, 'Admin With ID '.$_SESSION['AdminID'].' Failed Unexpectedly To Delete PDF File for Book With ID '.$bookid.' While Updating');
                        }
                    }

                    if(isUsed('PDF_File', 'books', $validBookFileName)){
                        $validBookFileName = validName($booksContainerFolder, $validBookFileName);
                    }

                    move_uploaded_file($bookTmp, $booksContainerFolder.$validBookFileName);
                }
                if(isset($prevCover)){
                    $validFrontCoverName = $currentBook['IMG_FrontCover'];
                } else {
                    // Delete the Previous Files(Book Cover)
                    if(file_exist($frontCoversContainerFolder.$currentBook['IMG_FrontCover'])){
                        if(unlink($frontCoversContainerFolder.$currentBook['IMG_FrontCover'])){
                            addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Deleted PDF File for Book With ID '.$bookid.' While Updating the Book Successfully');
                        } else {
                            addLog(4, 'Admin With ID '.$_SESSION['AdminID'].' Failed Unexpectedly To Delete PDF File for Book With ID '.$bookid.' While Deleting the Book');
                        }
                    }

                    if(isUsed('IMG_FrontCover', 'books', $validFrontCoverName)){
                        $validFrontCoverName = validName($frontCoversContainerFolder, $validFrontCoverName);
                    }

                    move_uploaded_file($coverTmp, $frontCoversContainerFolder.$validFrontCoverName);
                }
                $stmt = $db->prepare("UPDATE
                                        books
                                    SET
                                        Language       =   :lang,
                                        CatID          =   :catid,
                                        Name           =   :name,
                                        Description    =   :description,
                                        Author         =   :author,
                                        AllowComments  =   :commenting,
                                        PDF_File       =   :pdf_File,
                                        IMG_FrontCover =   :bookCover
                                    WHERE
                                        BookID = :bookid");
                $stmt->execute([
                        'lang'              =>      $bookLanguage,
                        'catid'             =>      $bookCatid, 
                        'name'              =>      $bookName,
                        'description'       =>      $bookDescription, 
                        'author'            =>      $bookAuthor, 
                        'commenting'        =>      $allowComments, 
                        'pdf_File'          =>      $validBookFileName, 
                        'bookCover'    =>      $validFrontCoverName, 
                        'bookid'            =>      $bookid
                ]); 
                addLog(1, 'User With ID '.$_SESSION['AdminID'].' Edited Book With ID '.$bookid.' Successfully');
                ?>
                <div class="alert alert-success rtl-dir-rtl w-50 d-flex justify-self-center flex-dir-column justify-content-center align-items-center gap-2 mt-150px">
                    <strong><?php echo lang("BOOK_UPDATED_SUCCESSFULLY") ?>!</strong>
                    <div>
                        <a class="btn btn-primary btn-sm" href='books.php?page=Manage'><?php echo lang("OKAY") ?>!</a>
                    </div>
                </div>
<?php       } else {
                foreach($arrErrors as $e){ 
                    addLog(1, "Admin With ID ".$_SESSION['AdminID']." Tried to Update Book With ID $bookid But Faced Some Errors on Validation");
                ?>
                    <div class="alert alert-danger justify-self-center w-50 text-center fw-bold mt-3 rtl-dir-rtl">
                        <?php echo $e ?>
                    </div>
        <?php   }?>
                <button class="btn btn-danger back-btn btn-sm">
                    <?php echo lang("BACK_BTN") ?>
                </button>
    <?php   }
        } else {
            header("Location: books.php?page=Manage");
        }
    } elseif($page=='Approve') {
        if(isUsed('BookID', 'books', $bookid)){
            $stmt = $db->prepare("UPDATE 
                                    books 
                                SET
                                    Approved = 1
                                WHERE 
                                    BookID = ?");
            $stmt->execute([$bookid]); 
            addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Approved the Book With ID '.$bookid.' Successfully');
            ?>
            <div class="alert alert-success w-50 d-flex justify-self-center flex-dir-column justify-content-center align-items-center gap-2 mt-150px rtl-dir-rtl">
                <strong><?php echo lang("BOOK_APPROVED_SUCCESSFULLY") ?>!</strong>
                <div>
                    <a class="btn btn-primary btn-sm" href='books.php?page=Manage'><?php echo lang("OKAY") ?>!</a>
                </div>
            </div>
<?php 
        } else { ?>
            <div class="alert alert-danger w-50 justify-self-center text-center mt-150px d-flex flex-dir-column rtl-dir-rtl">
                <strong><?php echo lang("NO_BOOK_WITH_THIS_ID") ?></strong>
                <div>
                    <a href="books.php?page=Manage" class='btn btn-danger btn-sm mt-2'>
                        <?php echo lang("BACK_BTN") ?>
                    </a>
                </div>
            </div>
<?php   }
    }
    ?></div><?php

    include $tpls.'footer.inc';
    ob_end_flush();