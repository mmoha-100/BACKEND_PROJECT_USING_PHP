<?php
    ob_start();
    session_start();

    $navbar = '';
    include 'init.inc';

    // After logging in Again We'll Come Back to This Page
    $_SESSION['lastPageAdmin'] = basename($_SERVER['REQUEST_URI']);

    if(!isset($_SESSION['AdminID'])){
        header("Location: index.php");
        exit();
    }?>
    <div class="container">
        <h1 class="section"><?php echo lang("DASHBOARD_SECTION") ?></h1>
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card bg-primary text-white user-select-none text-center">
                    <a href="books.php?page=Manage" class='text-white hover-ddd' title='<?php echo lang('TO_MANAGE_BOOKS') ?>'>
                        <div class="card-body">
                            <h5 class="card-title fs-3"><i class="fa-solid fa-book fa-fw me-2"></i><?php echo lang("TOTAL_BOOKS") ?></h5>
                            <p class="card-text fs-1"><?php echo countItems('books', 'BookID') ?></p>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-success text-white user-select-none text-center">
                    <a href="categories.php?page=Manage" class='text-white hover-ddd' title='<?php echo lang('TO_MANAGE_CATS') ?>'>
                        <div class="card-body">
                            <h5 class="card-title fs-3"><i class="fa-solid fa-list fa-fw me-2"></i><?php echo lang("TOTAL_CATS") ?></h5>
                            <p class="card-text fs-1"><?php echo countItems('categories', 'ID') ?></p>
                        </div>
                    </a>
                </div>
            </div>
                <div class="col-md-4">
                    <div class="card bg-info text-white user-select-none text-center">
                        <a href="users.php?page=Manage" class='text-white hover-ddd' title='<?php echo lang('TO_MANAGE_USERS') ?>'>
                            <div class="card-body">
                                <h5 class="card-title fs-3"><i class="fa-solid fa-users fa-fw me-2"></i><?php echo lang("TOTAL_USERS") ?></h5>
                                <p class="card-text fs-1"><?php echo countItems('users', 'UserID') ?></p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        <div class="card">
            <div class="card-body">
            <h5 class="rtl-align-right mb-3 pb-3 border-bottom card-title"><?php echo lang("RECENTLY_ADDED_BOOKS") ?></h5>
            <?php 
            $recentBooks = recentlyAdded('books', 5);
            if(!empty($recentBooks)){ 
                echo '<ul class="d-flex flex-dir-column gap-3">';
                foreach($recentBooks as $book){ ?>
                    <li class='rtl-row-reverse d-flex justify-content-between <?php if(!$book['Approved']) echo 'op-z-p-3'; ?>'>
                        <span>
                            <?php echo $book['Name'] ?>
                        </span>
                        <span>
                            <?php if(!$book['Approved']) {?>
                                    <button
                                        class='warningBtn btn btn-success btn-sm'
                                        data-url='books.php?page=Approve&bookid=<?php echo $book['BookID'] ?>'
                                        data-warning='<?php echo lang("WANT_TO_APPROVE_THE_BOOK") ?>'
                                        title='<?php echo lang('APPROVE_THE_BOOK') ?>'
                                    ><i class="fa-solid fa-power-off fa-fw"></i></button>

                            <?php } echo $book['Date'] ?>
                        </span>
                    </li>
        <?php   }
                echo '</ul>';
            }
            ?>
            </div>
        </div>
        </div>
    </div>
    </div>
    <?php

    include $tpls.'footer.inc';
    ob_end_flush();