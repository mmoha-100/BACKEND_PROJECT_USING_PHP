<?php
    session_start();
    ob_start();

    $pageTitle = 'Login';
    include 'init.inc';
    include $vars.'max_trails.inc';

    // Coming Back to Last Page
    $nextPage = isset($_SESSION['lastPageAdmin']) ? $_SESSION['lastPageAdmin'] : 'dashboard.php';

    $expirationSeconds = hoursToSeconds(1);

    if(!isset($_SESSION['failedTrials'])){
        $_SESSION['failedTrials'] = 0;
    }
    if($_SESSION['failedTrials'] == $maxTrials) {
        addLog(1, 'User Tried to Login and Then Blocked');
        setcookie('blocked', true, time() + $expirationSeconds);
        session_destroy(); // To Not Reset
        header("Location: blocked_user_page.php");
        exit();
    }
    if(isset($_COOKIE['blocked'])) {
        addLog(1, 'Blocked User Trying to Enter Again');
        header("Location: blocked_user_page.php");
        exit();
    }

    if(isset($_SESSION['AdminID'])){
        addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Logged in From Session');
        header("Location: $nextPage");
        exit();
    }

    if($_SERVER['REQUEST_METHOD']=='POST') {
        $username  =  $_POST['username'];
        $password  =  $_POST['password'];
        $email     =  $_POST['email'];

        addLog(1, 'a User Trying to Login With '.$username.' as a Username');

        $stmt = $db->prepare("SELECT 
                                UserID 
                            FROM 
                                users 
                            WHERE 
                                GroupID = 1
                            AND
                                Username = ? 
                            AND 
                                Password = ? 
                            AND 
                                Email = ?");
        $stmt->execute([$username, sha1($password), $email]);
        if($stmt->rowCount()) {
            $_SESSION['failedTrials'] = 0;
            $_SESSION['AdminID'] = $stmt->fetchColumn();
            addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Logged in Successfully');
            header("Location: $nextPage");
            exit();
        } else {
            $_SESSION['failedTrials']++;
            addLog(1, 'a User Made Used a Failed Trial From '.$maxTrials);
            ?>
            <div class="container mt-4">
                <div class="alert alert-danger text-center w-75 justify-self-center">
                    <h4 class='fw-bold'><?php echo lang("INCORRECT_INFO") ?></h4>
                    <p class='mb-0'><?php echo 'You Still Have ' . ($maxTrials + 1) - $_SESSION['failedTrials'] . ' Trial(s)'; ?></p>
                </div>
            </div>
<?php   }
    } ?>
    <h1 class='section'><?php echo lang("ADMIN_LOGIN_PAGE") ?></h1>
    <div class='container'>
        <ul class='d-flex gap-3 mb-2 rtl-row-reverse'>
            <?php foreach($langs as $key => $lang) { ?>
                    <li <?php if($_COOKIE['lang']==$key) echo 'class="op-z-p-3 pointer-none"' ?>>
                        <a class='user-select-none' href="index.php?lang=<?php echo $key ?>"><?php echo sharedlang(strtoupper($lang)) ?></a>
                    </li>
            <?php } ?>
        </ul>
        <form action="<?php $_SERVER['PHP_SELF'] ?>" method='POST' id='adminLoginForm'>
            <div class='group-inp rtl-row-reverse'>
                <label 
                for="username"
                class='rtl-dir-rtl'
                >
                <?php echo lang("USERNAME_FIELD_FORM")?>
                </label>
                <input 
                    autocomplete='off'
                    type="text" 
                    name="username" 
                    id="username"
                    required
                    <?php
                        if(isset($username)){
                            echo "value='$username'";
                        }
                    ?>
                    />
                </div>
                <div class='group-inp rtl-row-reverse'>
                    <label 
                        for="email"
                        class='rtl-dir-rtl'
                    >
                        <?php echo lang("EMAIL_FIELD_FORM")?>
                    </label>
                    <input 
                        autocomplete='off'
                        type="email" 
                        name="email" 
                        id="email"
                        required
                        <?php
                            if(isset($email)){
                                echo "value='$email'";
                            }
                        ?>
                    />
                </div>
                <div class='group-inp d-flex rtl-row-reverse'>
                    <label 
                    for="password"
                    class='rtl-dir-rtl'
                >
                    <?php echo lang("PASSWORD_FIELD_FORM")?>
                </label>
                <input 
                    autocomplete='off'
                    type="password" 
                    name="password"
                    id="password"
                    required
                    <?php
                        if(isset($password)){
                            echo "value='$password'";
                        }
                    ?>
                />
            </div>
            <input type="submit" value="<?php echo lang("SEND") ?>" class='btn btn-primary btn-sm inp-submit'>
        </form>        
    </div>
    <?php
    if(isset($_GET['lang'])){
        if(array_key_exists($_GET['lang'], $langs)){
            setcookie('lang', $_GET['lang'], time()+ daysToSeconds(365));
            header('Location: index.php');
        }
    }
    include $tpls.'footer.inc';
    ob_end_flush();