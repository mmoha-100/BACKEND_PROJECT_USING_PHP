<?php
    session_start();
    ob_start();
    $pageTitle = 'Categories';
    $navbar = '';
    
    include 'init.inc';

    $_SESSION['lastPageAdmin'] = basename($_SERVER['REQUEST_URI']);



    if(!isset($_SESSION['AdminID'])){
        addLog(1, 'a User Tried to Enter Categories Section Without Logging in');
        header("Location: index.php");
        exit();
    }

    $pages = ['Manage', 'Add', 'Insert', 'Delete', 'Edit', 'Update'];

    $page = isset($_GET['page']) && in_array($_GET['page'], $pages) ? $_GET['page'] : "Manage";
    $catid = isset($_GET['catid']) ?$_GET['catid']:0;

    $cats = getAll("categories");
    ?>
    <div class="container">
    <?php
    if($page == 'Manage') {
    ?>
        <?php if(!empty($cats)) { ?>
        <h1 class='section'><?php echo lang("MANAGE_CATS_SECTION") ?></h1>
        <div class="table-responsive">
            <table class="main-table table table-bordered text-center shadow-sm">
                <thead>
                    <th>#<?php echo lang("ID_TABLE_HEAD") ?></th>
                    <th><?php echo lang("NAME_TABLE_HEAD") ?></th>
                    <th><?php echo lang("DESCRIPTION_TABLE_HEAD") ?></th>
                    <th><?php echo lang("VISIBILITY_TABLE_HEAD") ?></th>
                    <th><?php echo lang("DATE_TABLE_HEAD") ?></th>
                    <th><?php echo lang("CONTROL_TABLE_HEAD") ?></th>
                </thead>
                <tbody>
                    <?php
                        foreach($cats as $cat){
                    ?>
                    <tr>
                        <td><?php echo $cat['ID'] ?></td>
                        <td><?php echo truncate($cat['Name'], 30) ?></td>
                        <td title='<?php echo $cat['Description'] ?>'><?php echo truncate($cat['Description'], 30) ?></td>
                        <td>
                            <?php 
                                echo $cat['Visibility'] ? '<span class="yes">'.lang("YES").'</span>':'<span class="no">'.lang("NO").'</span>';
                            ?>
                        </td>
                        <td><?php echo $cat['Date'] ?></td>
                        <td>
                            <div>
                                <a 
                                    href='categories.php?page=Edit&catid=<?php echo $cat['ID'] ?>' 
                                    class='btn btn-primary btn-sm'
                                    title='<?php echo lang("EDIT_THE_CAT") ?>'
                                >
                                    <i class="fa-solid fa-pen fa-fw"></i>
                                </a>
                                <button 
                                    class='btn btn-danger btn-sm warningBtn' 
                                    data-url='categories.php?page=Delete&catid=<?php echo $cat['ID'] ?>'
                                    data-warning='<?php echo lang('WANT_TO_DELETE_CAT') ?>'
                                    title='<?php echo lang("DELETE_THE_CAT") ?>'
                                >
                                    <i class='fa-solid fa-trash fa-fw'></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php   }?>
                </tbody>
            </table>
        </div>
        <a href='categories.php?page=Add' class="btn btn-primary btn-sm"><?php echo lang("ADD_BTN") ?></a>
        <?php 
            } else { ?>
                <div class="alert alert-primary d-flex justify-content-center w-50 justify-self-center flex-dir-column text-center mt-150px">
                    <p class='fw-bold'><?php echo lang("NO_CATS_TO_SHOW") ?></p>
                    <div>
                        <a class='btn btn-primary btn-sm' href="categories.php?page=Add"><?php echo lang("ADD_CATEGORY") ?></a>
                    </div>
                </div>
    <?php   }
        ?>
<?php } elseif($page == 'Add') {?>
        <h1 class='section'><?php echo lang("ADD_NEW_CAT_SECTION") ?></h1>
        <form action="<?php $_SERVER['PHP_SELF'] ?>?page=Insert" method='POST'>
            <div class='group-inp contains-required-inp rtl-row-reverse'>
                <label 
                for="name"
                class='rtl-align-right rtl-dir-rtl'
                >
                <?php echo lang("CATEGORY_NAME_FIELD_FORM")?>
                </label>
                <input 
                    type="text" 
                    name="name" 
                    id="name"
                    placeholder='<?php echo lang("BETWEEN_5_AND_100") ?>'
                    required
                />
            </div>
            <div class='group-inp contains-required-inp rtl-row-reverse'>
                <label 
                    for="description"
                    class='rtl-align-right rtl-dir-rtl'
                >
                    <?php echo lang("CATEGORY_DESCRIPTION_FIELD_FORM")?>
                </label>
                <textarea 
                    type="text" 
                    name="description" 
                    placeholder='<?php echo lang("BETWEEN_8_AND_600") ?>'
                    id="description"
                    required
                    onKeyup='adjustHeight(this)'
                ></textarea>
            </div>
            <div class='group-inp d-flex contains-required-inp rtl-row-reverse'>
                <label class='rtl-align-right rtl-dir-rtl'>
                    <?php echo lang("CATEGORY_VISIBILITY_FIELD_FORM")?>
                </label>
            <div class="radio-inp-group rtl-row-reverse">
                <div>
                    <label for="visible"><?php echo lang("VISIBLE_CATEGORY")?></label>
                    <input 
                        type="radio" 
                        name="visibility"
                        id="visible"
                        value='1'
                        required
                        checked
                    />
                </div>
                <div>
                    <label for="invisible" class='rtl-align-right rtl-dir-rtl'><?php echo lang("INVISIBLE_CATEGORY")?></label>
                    <input 
                        type="radio" 
                        name="visibility"
                        id="invisible"
                        value='0'
                        required
                    />
                    </div>
                </div>
            </div>
            <input type="submit" value="<?php echo lang("ADD_BTN") ?>" class='btn btn-primary btn-sm'>
            <button class="btn btn-danger back-btn btn-sm">
                <?php echo lang("BACK_BTN") ?>
            </button>
        </form>
<?php } elseif($page=='Insert') { 
            if($_SERVER['REQUEST_METHOD']=='POST') {
                if(!isset($_POST['name'])){
                    $catName            =   '';
                } else {
                    $catName            =   trim(filter_var($_POST['name'], FILTER_SANITIZE_STRING));
                }

                if(!isset($_POST['description'])){
                    $catDescription     =   '';
                } else {
                    $catDescription     =   trim(filter_var($_POST['description'], FILTER_SANITIZE_STRING));
                }

                if(!isset($_POST['visibility'])||!is_numeric($_POST['visibility'])||$_POST['visibility']==''){
                    $catVisibility = 0;
                } else {
                    $catVisibility      =   $_POST['visibility'];
                }

                $arrErrors = [];

                if($catName == ''){
                    $arrErrors[] = lang("CAT_NAME_MUST_NOT_BE_EMPTY");
                } else {
                    if(isUsed("Name", "categories", $catName)){
                        $arrErrors[] = lang("CAT_NAME_USED_BEFORE");
                    }
                    if(containsBadWord($catName)){
                        $arrErrors[] = lang("CAT_NAME_CONTAINS_BAD_WORD");
                    }
                    if(strlen($catName) < 5 || strlen($catName) > 100){
                        $arrErrors[] = lang("CAT_NAME_MUST_BE_BETWEEN");
                    }
                }
                if($catDescription == ''){
                    $arrErrors[] = lang("CAT_DESCRIPTION_MUST_NOT_BE_EMPTY");
                } else {
                    if(containsBadWord($catDescription)){
                        $arrErrors[] = lang("CAT_DESCRIPTION_CONTAINS_BAD_WORD");
                    }
                    if(strlen($catDescription) < 5 || strlen($catDescription) > 600){
                        $arrErrors[] = lang("CAT_DESCRIPTION_MUST_BE_BETWEEN");
                    }
                }

                if(!empty($arrErrors)){ 
                    addLog(1, "Admin With ID ".$_SESSION['AdminID']." Tried to Insert Category But Faced Some Errors on Validation");
                    foreach($arrErrors as $e){ ?>
                    <div class="alert alert-danger fw-bold">
                        <?php echo $e ?>
                    </div>
        <?php   } ?>
                <button class="btn btn-danger back-btn btn-sm">
                    <?php echo lang("BACK_BTN") ?>
                </button>
            <?php
            } else {
                $stmt = $db->prepare("INSERT INTO 
                                        categories(Name, Description, Visibility, Date)
                                    VALUES
                                        (:name, :description, :visibility, now())");
                $stmt->execute([
                    'name'          =>  $catName,
                    'description'   =>  $catDescription,
                    'visibility'    =>  $catVisibility,
                ]);
                if($stmt->rowCount()){
                    addLog(1, 'User With ID '.$_SESSION['AdminID'].' Inserted Category With Name "'.$catName .'" Successfully'); 
                    ?>
                    <div class="alert alert-success w-50 d-flex text-center justify-self-center flex-dir-column justify-content-center align-items-center gap-2 mt-150px">
                        <strong><?php echo lang("CAT_ADDED_SUCCESSFULLY") ?>!</strong>
                        <div>
                            <a class="btn btn-primary btn-sm" href='categories.php?page=Manage'><?php echo lang("OKAY") ?>!</a>
                        </div>
                    </div>
                    <?php
                } else{
                    addLog(4, 'User With ID '.$_SESSION['AdminID'].' Failed Unexpectedly to Insert Category With Name "'.$catName.'"');?>
                        <div class="alert alert-warning justify-self-center">
                            <?php echo lang("SOMETHING_WENT_WRONG") ?>
                            <a href="dashboard.php"><?php echo lang("GO_BACK_TO_HOME") ?></a>
                        </div>
        <?php   }
                }
            } else {
                header("Location: categories.php?page=Add");
            }
        ?>
<?php } elseif($page=='Delete') {
            if(isUsed('ID', 'categories', $catid)){
                $stmt = $db->prepare("DELETE FROM categories WHERE ID = ?");
                $stmt->execute([$catid]);
                if($stmt->rowCount()) { 
                    addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Deleted Category With ID '.$catid.' Successfully');
                    header("Location: categories.php?page=Manage");
                } else {
                    addLog(4, 'Admin With ID '.$_SESSION['AdminID'].' Failed Unexpectedly to Delete Category With ID '.$catid);
                    ?>
                    <div class="alert alert-warning justify-self-center">
                        <?php echo lang("SOMETHING_WENT_WRONG") ?>
                        <a href="dashboard.php"><?php echo lang("GO_BACK_TO_HOME") ?></a>
                    </div>
                    <?php
                }
            } else { ?>
                <div class="alert alert-danger w-50 justify-self-center text-center mt-150px d-flex flex-dir-column">
                    <strong><?php echo lang("NO_CAT_WITH_THIS_ID") ?></strong>
                    <div>
                        <a href="categories.php?page=Manage" class='btn btn-danger btn-sm mt-2'>
                            <?php echo lang("BACK_BTN") ?>
                        </a>
                    </div>
                </div>
    <?php   }
    } elseif($page=='Edit'){
        $stmt = $db->prepare("SELECT * FROM categories WHERE ID = ?");
        $stmt->execute([$catid]);
        $currentCat = $stmt->fetch();
        if($stmt->rowCount()) {
            ?>
                <h1 class="section"><?php echo lang("EDIT_CAT_SECTION")?></h1>
                <form action="<?php $_SERVER['PHP_SELF'] ?>?page=Update&catid=<?php echo $catid ?>" method='POST'>
                    <div class='group-inp contains-required-inp rtl-row-reverse'>
                        <label 
                        for="name"
                        class='rtl-dir-rtl'
                        >
                        <?php echo lang("CATEGORY_NAME_FIELD_FORM")?>
                        </label>
                        <input 
                            type="text" 
                            name="name" 
                            id="name"
                            required
                            value='<?php echo $currentCat['Name'] ?>'
                        />
                        </div>
                        <div class='group-inp rtl-row-reverse'>
                            <label 
                                for="description"
                                class='rtl-dir-rtl'
                            >
                                <?php echo lang("CATEGORY_DESCRIPTION_FIELD_FORM")?>
                            </label>
                            <textarea 
                                type="text" 
                                name="description" 
                                id="description"
                                required
                                onKeyup='adjustHeight(this)'
                            ><?php echo $currentCat['Description'] ?></textarea>
                        </div>
                        <div class='group-inp d-flex contains-required-inp rtl-row-reverse'>
                            <label class='rtl-dir-rtl'>
                                <?php echo lang("CATEGORY_VISIBILITY_FIELD_FORM")?>
                            </label>
                        <div class="radio-inp-group rtl-row-reverse">
                            <div>
                                <label for="visible"><?php echo lang("VISIBLE_CATEGORY")?></label>
                                <input 
                                    type="radio" 
                                    name="visibility"
                                    id="visible"
                                    value='1'
                                    required
                                    <?php
                                        if($currentCat['Visibility']){
                                            echo 'checked';
                                        }
                                    ?>
                                />
                            </div>
                            <div>
                                <label for="invisible"><?php echo lang("INVISIBLE_CATEGORY")?></label>
                                <input 
                                    type="radio" 
                                    name="visibility"
                                    id="invisible"
                                    value='0'
                                    required
                                    <?php
                                        if(!$currentCat['Visibility']){
                                            echo 'checked';
                                        }
                                    ?>
                                />
                            </div>
                        </div>
                    </div>
                    <input type="submit" value="<?php echo lang("UPDATE_BTN") ?>" class='btn btn-primary btn-sm'>
                    <button class="btn btn-danger back-btn btn-sm">
                        <?php echo lang("BACK_BTN") ?>
                    </button>
                </form>
            <?php
        } else { ?>
            <div class="alert alert-danger w-50 justify-self-center text-center mt-150px d-flex flex-dir-column">
                <strong><?php echo lang("NO_CAT_WITH_THIS_ID") ?></strong>
                <div>
                    <a href="categories.php?page=Manage" class='btn btn-danger btn-sm mt-2'>
                        <?php echo lang("BACK_BTN") ?>
                    </a>
                </div>
            </div>
<?php   }
    } elseif($page=='Update') {
            if($_SERVER['REQUEST_METHOD'] == 'POST') {
                if(!isset($_POST['name'])){
                    $name            =   '';
                } else {
                    $name            =   trim(filter_var($_POST['name'], FILTER_SANITIZE_STRING));
                }
                if(!isset($_POST['name'])){
                    $description     =   '';
                } else {
                    $description     =   trim(filter_var($_POST['description'], FILTER_SANITIZE_STRING));
                }

                if(!isset($_POST['visibility']) || !is_numeric($_POST['visibility']) || $_POST['visibility'] == ''){
                    $visibility      =   0;
                } else {
                    $visibility      =   $_POST['visibility'];
                }


                $arrErrors = [];

                if($name==''){
                    $arrErrors[] = lang("CAT_NAME_MUST_NOT_BE_EMPTY");    
                } else {
                    if(strlen($name) > 100 || strlen($name) < 5){
                        $arrErrors[] = lang("CAT_NAME_MUST_BE_BETWEEN");
                    }
                }
                if(!isSameWithPrevious('ID',$catid, 'Name', $name, 'categories') && isUsed('Name', 'categories', $name)) {
                    $arrErrors[] = lang("CAT_NAME_USED_BEFORE");
                }
                if(containsBadWord($name)){
                    $arrErrors[] = lang("CAT_NAME_CONTAINS_BAD_WORD");
                }
                
                if($description == '') {
                    $arrErrors[] = lang("CAT_DESCRIPTION_MUST_NOT_BE_EMPTY");
                } else {
                    if(strlen($description) < 5 || strlen($description) > 500){
                        $arrErrors[] = lang("CAT_DESCRIPTION_MUST_BE_BETWEEN");
                    }
                }
                if(containsBadWord($description)){
                    $arrErrors[] = lang("CAT_DESCRIPTION_CONTAINS_BAD_WORD");
                }

                if(empty($arrErrors)){
                    $stmt =$db->prepare("UPDATE 
                                            categories 
                                        SET
                                            Name         =  ?,
                                            Description  =  ?,
                                            Visibility   = ?
                                        WHERE 
                                            ID = ?");
                    $stmt->execute([$name, $description, $visibility, $catid]);
                    addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Updated Category With ID '.$catid.' Successfully');
                    ?>
                        <div class="alert alert-success w-50 justify-self-center text-center mt-150px d-flex flex-dir-column">
                            <strong><?php echo lang("UPDATED_CAT_SUCCESSFULLY") ?></strong>
                            <div>
                                <a href="categories.php?page=Manage" class='btn btn-success btn-sm mt-2'>
                                    <?php echo lang("BACK_BTN") ?>
                                </a>
                            </div>
                        </div>
        <?php   } else {
                    addLog(1, "Admin With ID ".$_SESSION['AdminID']." Tried to Update Category With ID $catid But Faced Some Errors on Validation");
                    foreach($arrErrors as $e){ 
                        ?>
                        <div class="alert alert-danger fw-bold">
                            <?php echo $e ?>
                        </div>
            <?php   }
                }
            } else {
                header('Location: categories.php?page=Manage');
                exit();
            }
    } else {
        header("Location: categories.php");
        exit();
    }
    ?>
    </div>
    <?php
    include $tpls.'footer.inc';
    ob_end_flush();