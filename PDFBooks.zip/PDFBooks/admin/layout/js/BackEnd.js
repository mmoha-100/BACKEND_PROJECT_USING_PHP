if ( window.history.replaceState ) {
    window.history.replaceState(null, null, window.location.href);
}

const adminLoginForm = document.getElementById("adminLoginForm");
if (adminLoginForm !== null) {
    const username   =    document.querySelector("#username");
    const email      =   document.querySelector("#email");
    const password   =   document.querySelector("#password");
    const adminSubmitBtn = document.querySelector(".inp-submit");
    window.onmousemove = () => { 
        if (username.value == '' || email.value == '' || password.value == '') {
            adminSubmitBtn.classList.add('disabled');
        } else {
            adminSubmitBtn.classList.remove('disabled');
        }
    }
}

const logoutNavbarBtn = document.getElementById("logoutNavbarBtn");

if (logoutNavbarBtn !== null) {
    logoutNavbarBtn.onclick = () => {
        if (confirm(logoutNavbarBtn.dataset.warning)) {
            location.href = logoutNavbarBtn.dataset.url;
        }
    }
}

const showNavbarBtn = document.getElementById("showNavbarBtn");
const navbarContainer = document.getElementById("navbarContainer");

if (showNavbarBtn !== null) {
    showNavbarBtn.onclick = () => {
        if (navbarContainer.classList.contains('hidden-navbar')) {
            navbarContainer.classList.remove('hidden-navbar');
        } else {
            navbarContainer.classList.add('hidden-navbar');
        }
    }
    document.body.addEventListener("click", (e) => {
        if (e.target != showNavbarBtn && !navbarContainer.classList.contains('hidden-navbar')) {
            navbarContainer.classList.add('hidden-navbar');
        }
    })
}

const backBtns = document.querySelectorAll("button.back-btn");
backBtns.forEach((btn) => {
    btn.onclick = () => { 
        history.back();
    }
})

function adjustHeight(el){
    el.style.height = (el.scrollHeight > el.clientHeight) ? (el.scrollHeight)+"px" : "35px";
}

const warningBtn = document.querySelectorAll(".warningBtn");
if (warningBtn !== null) {
    warningBtn.forEach(btn => {
        btn.onclick = () => {
            if (confirm(btn.dataset.warning)) {
                location.href = btn.dataset.url;
            }
        }
    });
}


const frontCoverBookImgInp = document.getElementById("frontCoverBookImg");
const ImgContainer = document.getElementById("coverImgContainer");
const imgElement = document.createElement("img");

// JS Doesn't Make Any Sense; if You Use Arrow Function Here It'll Not Work
if (frontCoverBookImgInp !== null) {
    ImgContainer.appendChild(imgElement);
    let uploadedImgSrc = '';
    frontCoverBookImgInp.addEventListener("change", function () {
    const reader = new FileReader();
    reader.addEventListener("load", () => {
        imgElement.src = reader.result;
    })
    frontCoverBookImgInp.style.height = 'fit-content';
    reader.readAsDataURL(this.files[0]);
});
}