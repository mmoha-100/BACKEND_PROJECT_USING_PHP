<?php
    session_start();
    ob_start();

    $navbar     =  '';
    $pageTitle  =  'Settings';

    include 'init.inc';

    $_SESSION['lastPageAdmin'] = basename($_SERVER['REQUEST_URI']);
    
    if(!isset($_SESSION['AdminID'])) {
        header("Location: index.php");
        exit();
    }
    if($_SERVER['REQUEST_METHOD']=='POST') {
        if(isset($_POST['libName']) && $_POST['libName'] != ''){
            $stmt = $db->prepare("UPDATE general_settings SET LibraryName = ?");
            $stmt->execute([$_POST['libName']]);
            if(!containsBadWord($_POST['libName'])){
                addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Changed Library\' Name to '.$_POST['libName']);
            } else {
                // No Bad Words, Bad Word = No Admin >:(
                addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Tried to Change Library Name But Used Bad Word'); 
            }
        }
        if(isset($_POST['libDescription']) && $_POST['libDescription'] != ''){
            $stmt = $db->prepare("UPDATE general_settings SET LibraryDescription = ?");
            $stmt->execute([$_POST['libDescription']]);
            if(!containsBadWord($_POST['liBDescription'])){
                addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Changed Library\' Description to '.$_POST['libDescription']);
            } else {
                // No Bad Words, Bad Word = No Admin >:(
                addLog(1, 'Admin With ID '.$_SESSION['AdminID'].' Tried to Change Library Description But Used Bad Word'); 
            }
        }
        if(isset($_POST['lang']) && array_key_exists($_POST['lang'], $langs)) {
            $lang = $_POST['lang'];
            setcookie('lang', $_POST['lang'], time()+daysToSeconds(365));
        }

        if(isset($_POST['theme']) && in_array($_POST['theme'],['light','dark'])){
            $theme = $_POST['theme'];
            setcookie('theme', $theme, time()+daysToSeconds(365));
        }

        // Apply Changes Almost by Reloading the Page
        header("Location: settings.php");
        exit();
    } ?>
    <div class="container">
        <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method='POST'>
            <div class="row gap-4 justify-content-center rtl-row-reverse">
                <div class='col-sm-full col-lg-5'>
                    <div class="card">
                        <div class="card-header rtl-align-right"><?php echo lang("GENERAL_SETTINGS") ?></div>
                        <div class="card-body rtl-row-reverse">
                            <div class='d-flex justify-content-between rtl-row-reverse'>
                                <label for="libName" class='rtl-dir-rtl'><?php echo lang("LIBRARY_NAME_FIELD") ?>:</label>
                                <input type="text" name='libName' id='libName'>
                            </div>
                            <div class='d-flex justify-content-between mt-2 rtl-row-reverse'>
                                <label for="libDescription" class='rtl-dir-rtl'><?php echo lang("LIBRARY_DESCRIPTION_FIELD") ?>:</label>
                                <input type="text" name='libDescription' id='libDescription'>
                            </div>
                            <div class='mt-4 d-flex gap-4 rtl-row-reverse'>
                                <a href="settings.php?page=clear_cache">
                                    <?php echo lang("CLEAR_BROWSER_CACHE") ?>
                                </a>
                                <a href="logs.txt" download>
                                    <?php echo lang("DOWNLOAD_LOGS_FILE") ?>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class='col-sm-full col-lg-5'>
                    <div class="card">
                        <div class="card-header w-full rtl-align-right">
                            <?php echo lang("APPEARANCE") ?>
                        </div>
                        <div class="card-body">
                                <div class='w-50 d-flex justify-self-center rtl-row-reverse d-flex justify-content-between'>
                                    <?php echo lang("LANGUAGE") ?>
                                    <select name="lang" id='lang'>
                                        <?php foreach($langs as $key => $lang){ ?>
                                            <option <?php if($key==$_COOKIE['lang']) echo 'selected' ?> value='<?php echo $key ?>'><?php echo sharedlang(strtoupper($lang)) ?></option>
                                            <?php   } ?>
                                        </select>
                                    </div>
                                    <div class='w-50 justify-content-center justify-self-center mt-4'>
                                        <div class='d-flex justify-content-between rtl-row-reverse'>
                                            <label class='pointer' for="dark"><?php echo lang("DARK_THEME") ?></label>
                                            <input class='pointer' type="radio" name="theme" <?php  if($_COOKIE['theme'] == 'dark') echo "checked" ?> value='dark' id="dark">
                                        </div>
                                        <div class='d-flex justify-content-between rtl-row-reverse'>
                                            <label class='pointer' for='light' for="light"><?php echo lang("LIGHT_THEME") ?></label>
                                            <input class='pointer' type="radio"  <?php if($_COOKIE['theme'] == 'light') echo "checked" ?>  name="theme" value='light' id="light">
                                        </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <div class='col-sm-full col-lg-5'>
                        <div class="card">
                            <div class="card-header rtl-align-right"><?php echo lang("BOOKS_SETTINGS") ?></div>
                            <div class="card-body d-flex gap-4 rtl-row-reverse">
                                <a href="#" class='text-danger user-select-none op-z-p-3 pointer-none'>
                                    <?php echo lang('ADD_NEW_DISCOUNT') ?>
                                </a>
                                <?php  ?>
                                <a href="#" download class='text-danger user-select-none op-z-p-3 pointer-none'>
                                    <?php echo lang('DOWNLOAD_ALL_BOOKS') ?>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <input type="submit" value='<?php echo lang("SAVE_CHANGES_BTN") ?>' class='mt-4'>
            </div>
        </form>
    </div>                                        
        <?php
        if(isset($_GET['page']) && $_GET['page']=='clear_cache'){
            if (ini_get('opcache.enable')) {// non-useful (can't clean)
                opcache_reset();
            }
        }
    include $tpls.'footer.inc'; 
    ob_end_flush();