<?php
    session_start();
    ob_start();

    $pageTitle  =  'Logs';
    $navbar     =  '';

    include 'init.inc';

    $_SESSION['lastPageAdmin'] = basename($_SERVER['REQUEST_URI']);
    
    if(!isset($_SESSION['AdminID'])) {
        addLog(1, 'a User Tried to Enter Logs Section Without Logging in');
        header("Location: index.php");
        exit();
    }

    $logs    =  getLogs();
    $levels  =  ['DEBUG', 'INFO', 'NOTICE', 'WARN', 'ERROR', 'FATAL'];
    $chosenLevel    =  isset($_GET['level']) && in_array($_GET['level'], $levels) ? $_GET['level']:'ALL';
?>
<div class="container">
<?php
    if(!empty($logs)){ ?>
    <h1 class='section'><?php echo lang("LOGS_SECTION") ?></h1>
    <ul class="logs-types rtl-justify-content-right">
        <li <?php if($chosenLevel=='ALL') echo 'class="op-z-p-3"' ?>>
            <a href="logs.php?level=ALL"><?php echo lang('ALL_LEVELS') ?></a>
        </li>
<?php foreach($levels as $level) { ?>
        <li <?php if($level == $chosenLevel) echo 'class="op-z-p-3"' ?>>
            <a href="logs.php?level=<?php echo $level ?>"><?php echo $level ?></a>
        </li>
<?php } ?>
    </ul>
    <table class="logs-table table table-striped">
        <thead class='user-select-none'>
            <tr>
                <th scope="col"><?php echo lang("LOGS_TIMESTAMP_TABLE_HEAD") ?></th>
                <th scope="col"><?php echo lang("LOGS_LOG_LEVEL_TABLE_HEAD") ?></th>
                <th scope="col"><?php echo lang("LOGS_MESSAGE_TABLE_HEAD") ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($logs as $log) { 
                    if(($log['level'])===$chosenLevel || $chosenLevel=='ALL'){?>
                    <tr>
                        <td><?php echo $log['timestamp'] ?></td>
                        <td><?php echo $log['level'] ?></td>
                        <td><?php echo $log['msg'] ?></td>
                    </tr>
            <?php   } 
                  } ?>
        </tbody>
    </table>
<?php    } else { ?>
            <div class="alert alert-primary d-flex justify-content-center w-50 justify-self-center flex-dir-column text-center mt-150px">
                <p class='fw-bold'><?php echo lang("NO_LOGS_TO_SHOW") ?></p>
                <div>
                    <a class='btn btn-primary btn-sm' href="dashboard.php"><?php echo lang("GO_BACK_TO_HOME") ?></a>
                </div>
            </div>
<?php    } ?>
</div>
    <?php
    include $tpls.'footer.inc';