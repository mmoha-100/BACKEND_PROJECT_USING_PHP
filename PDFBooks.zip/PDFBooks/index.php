<?php
    ob_start();
    session_start();
    $_SESSION['lastPage'] = basename($_SERVER['REQUEST_URI']);
    $navbar = '';
    include 'init.inc'; 
?>
    <div class="container"> 
        <h1 class="section"><?php echo lang('RECENTLY_ADDED_BOOKS') ?></h1>
        <?php
            foreach(recentlyAdded('books', 5) as $book){ 
                displayBook($book);
            }
        ?>
        <a href="categories.php" class='p-3 d-block'><?php echo lang("SHOW_ALL_CATEGORIES") ?></a>
    </div>
    <?php
    include $tpls.'footer.inc';
    ob_end_flush();