<?php
    session_start();
    if(isset($_SESSION['Username'])){
        session_destroy();
        header('Location: '.$_SESSION['lastPage']);
    }else{
        if(isset($_SESSION['lastPage'])){
            header('Location: '.$_SESSION['lastPage']);
        }else{
            header("Location: index.php");
        }
    }