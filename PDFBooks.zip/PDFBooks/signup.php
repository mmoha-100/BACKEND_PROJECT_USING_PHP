<?php
    $navbar = '';
    $pageTitle='Login | Signup';
    include 'init.inc';
    session_start();
    ob_start();
    if(isset($_SESSION['Username'])){
        header("Location: index.php");
    }
    if($_SERVER['REQUEST_METHOD']=='POST'){
        $arrErrors = [];

        if(isset($_POST['username'])){
            $username = filter_var($_POST['username'], FILTER_SANITIZE_STRING);
        } else {
            $username = '';
        }

        if(isset($_POST['email'])){
            $email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
        } else {
            $email = '';
        }

        if(isset($_POST['fullName'])){
            $fullName = filter_var($_POST['fullName'], FILTER_SANITIZE_STRING);
        } else {
            $fullName = '';
        }

        if(isset($_POST['password'])){
            $password = filter_var($_POST['password'], FILTER_SANITIZE_STRING);
        } else {
            $password = '';
        }

        if($username == ''){
            $arrErrors[] = lang('USERNAME_CANT_BE_EMPTY');
        } else {
            if(containsBadWord($username)){
                $arrErrors[] = lang('USERNAME_CONTAINS_BAD_WORDS');
            }
            if(isUsed('Username', 'users', $username)){
                $arrErrors[]=lang('USERNAME_USED_BEFORE');
            }
            if(strlen($username) >  100 || strlen($username) < 5){
                $arrErrors[] = lang('USERNAME_MUST_BE_BETWEEN');
            }
        }

        if($email == ''){
            $arrErrors[] = lang('EMAIL_CANT_BE_EMPTY');
        } else {
            if(containsBadWord($email)){
                $arrErrors[] = lang('EMAIL_CONTAINS_BAD_WORDS');
            }
            if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
                $arrErrors[] = lang("INVALID_EMAIL");
            }
            if(isUsed('Email', 'users', $email)){
                $arrErrors[] = lang('EMAIL_USED_BEFORE');
            }
        }

        if($fullName == ''){
            $arrErrors[] = lang('FULLNAME_CANT_BE_EMPTY');
        } else {
            if(containsBadWord($email)){
                $arrErrors[] = lang('FULLNAME_CONTAINS_BAD_WORDS');
            }
            if(strlen($fullName) >  100 || strlen($fullName) < 5){
                $arrErrors[] = lang('FULLNAME_MUST_BE_BETWEEN');
            }
        }

        if($password == ''){
            $arrErrors[] = lang('PASSWORD_CANT_BE_EMPTY');
        } else {
            if(strlen($password) >  100 || strlen($password) < 5){
                $arrErrors[] = lang('PASSWORD_MUST_BE_BETWEEN');
            }
        }
        
        if(empty($arrErrors)) {
            $stmt = $db->prepare("INSERT INTO
                                    users(Username, Email, FullName, Password, RegStatus, GroupID, Date)
                                VALUES(:username, :email, :fullName, :password, 0, 0, now())");
            $stmt->execute([
                'username'  =>  $username,
                'email'     =>  $email,
                'fullName'  =>  $fullName,
                'password'  =>  sha1($password),
            ]);
            $stmt = $db->prepare("SELECT 
                                    UserID 
                                FROM 
                                    users 
                                WHERE
                                    Username = ?
                                ");
            $stmt->execute([$username]);
            $_SESSION['UserID']  = $stmt->fetchColumn();
            $_SESSION['Username'] = $username;

            if(isset($_SESSION['lastPage'])){
                $lastPage = $_SESSION['lastPage'];
            } else {
                $lastPage = 'index.php';
            }
            header("Location: $lastPage");
        } else { 
            foreach($arrErrors as $e){ ?>
            <div class="container mt-4">
                <div class="alert alert-danger text-center w-75 justify-self-center">
                    <h6 class='fw-bold'><?php echo $e ?></h6>
                </div>
            </div>
    <?php }  
        }
    } ?> 
<div class="container mt-5">
    <h1 class="section"><?php echo lang("SIGN_UP_SECTION") ?></h1>
    <form action="<?php $_SERVER['PHP_SELF'] ?>" method='POST' id='adminLoginForm'>
        <div class='group-inp rtl-row-reverse'>
            <label 
            for="username"
            class='rtl-dir-rtl'
            >
            <?php echo lang("NEW_USERNAME_FIELD_FORM")?>
        </label>
        <input 
        type="text" 
                    name="username" 
                    id="username"
                    required
                    autocomplete='off'
                    <?php
                        if(isset($username)){
                            echo "value='$username'";
                        }
                        ?>
                    />
                </div>
                <div class='group-inp rtl-row-reverse'>
                    <label 
                    for="email"
                        class='rtl-dir-rtl'
                        >
                        <?php echo lang("NEW_EMAIL_FIELD_FORM")?>
                    </label>
                    <input 
                    autocomplete='off'
                    type="email" 
                    name="email" 
                    id="email"
                    required
                        <?php
                            if(isset($email)){
                                echo "value='$email'";
                            }
                        ?>
                    />
                </div>
                <div class='group-inp rtl-row-reverse'>
                    <label 
                    for="fullName"
                        class='rtl-dir-rtl'
                        >
                        <?php echo lang("NEW_FULLNAME_FIELD_FORM")?>
                    </label>
                    <input 
                    autocomplete='off'
                    type="text" 
                    name="fullName" 
                    id="fullName"
                    required
                        <?php
                            if(isset($fullName)){
                                echo "value='$fullName'";
                            }
                        ?>
                    />
                </div>
                <div class='group-inp d-flex rtl-row-reverse'>
                    <label 
                    for="password"
                    class='rtl-dir-rtl'
                >
                <?php echo lang("NEW_PASSWORD_FIELD_FORM")?>
                </label>
                <input 
                    autocomplete='off'
                    type="password" 
                    name="password"
                    id="password"
                    required
                    <?php
                        if(isset($password)){
                            echo "value='$password'";
                        }
                    ?>
                />
            </div>
            <input type="submit" value="<?php echo lang("SIGN_UP_BTN") ?>" class='btn btn-primary btn-sm inp-submit'>
        </form>     
        <a href="login.php"><?php echo lang("LOGIN_URL") ?></a>
    </div>

<?php
    include $tpls.'footer.inc';
    ob_end_flush();